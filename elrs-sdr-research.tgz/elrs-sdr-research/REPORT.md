# ELRS SDR Capture & Decode — Research Report

Date: 2026-09-28
Environment: anl01.an.dd (VLAN 716, no direct internet). Working proxy for GitHub:
`http://10.71.7.12:3142` (apt cache node). All clones/API calls went through it.
GitHub search API: 10 req/min unauthenticated — space queries ~15s.

All material lives under: /home/andeds-agent/elrs-sdr-research/
  - ExpressLRS/                          (cloned, depth 1, current main)
  - GNU_Radio_ExpressLRS/                (cloned)
  - ELRS-ESP32-Channel-Decoder/          (cloned)
  - LoRa-ELRS-Interceptor-Decoder/       (cloned)
  - Expresslrs-Ghost-RX/                 (cloned)

================================================================================
1. ELRS PROTOCOL BASICS
================================================================================

1.1 Air interface
- Modern ELRS is LoRa (chirp spread spectrum) + FHSS. Chips: SX127x (2.4 GHz
  classic), SX1280, LR1121, LR2021 (868/915 + 2.4 dual-band).
  Drivers: src/lib/SX127xDriver/, SX1280Driver/, LR1121Driver/, LR2021Driver/.
- CC2400 (GFSK) is LEGACY ELRS 2.x — the driver is GONE from current main.
  Only relevant if you must decode old 2.x gear.
- Newer SX1280/LR11xx/LR2021 2.4 GHz targets can also use "FLRC" (GFSK-like
  0.65 MHz symbol rate) at 500/1000 Hz — see rate tables below.
- SDR implication: 2.4 GHz LoRa @ 800 kHz BW -> capture ~4-8 MS/s.
  915 MHz LoRa @ 500 kHz BW -> capture ~2.5-4 MS/s. B210/B205 handle both easily.

1.2 Air-rate tables (verified, src/src/common.cpp)
Per-chip tables, selected at build time via RADIO_* define.

RADIO_SX127X (900 MHz band only; the classic 2.4 SX127x targets use SF11/12@250/500k
which is NOT in this 900 table — those 2.4 SX127x rates are defined in the
target headers, e.g. SX127x_SF_11/SF_12, BW_250_00/BW_500_00):
  idx  rate              BW          SF   CR     preamble  TLM   interval(us) pkt
  0    900 200Hz         500kHz      SF6  4/7    8         1/64  5000         OTA4
  1    900 100Hz 8ch     500kHz      SF6  4/8    8         1/32  10000        OTA8
  2    900 100Hz         500kHz      SF7  4/7    8         1/32  10000        OTA4
  3    900 50Hz          500kHz      SF8  4/7    10        1/16  20000        OTA4
  4    900 25Hz          500kHz      SF9  4/7    10        1/8   40000        OTA4
  5    900 50Hz DVDA     500kHz      SF6  4/7    8         1/64  5000         OTA4 (x4 sends)

RADIO_SX128X (2.4 GHz):
  FLRC 2G4 1000/500/250 Hz: BR 0.65MHz BW 0.6, BT 1, CR 1/2, preamble 32
  LORA 2G4 500Hz   : BW800 SF5 4/6 preamble12 TLM1/128 interval2000  OTA4
  LORA 2G4 333Hz 8ch: BW800 SF5 4/8 preamble12 TLM1/128 interval3003 OTA8
  LORA 2G4 250Hz   : BW800 SF6 4/8 preamble14 TLM1/64  interval4000  OTA4
  LORA 2G4 150Hz   : BW800 SF7 4/8 preamble12 TLM1/32  interval6666  OTA4
  LORA 2G4 100Hz 8ch: BW800 SF7 4/8 preamble12 TLM1/32  interval10000 OTA8
  LORA 2G4 50Hz   : BW800 SF8 4/8 preamble12 TLM1/16  interval20000 OTA4

LR1121/LR2021 add GFSK 300k/467k fdev100k modes + the same LORA 2G4 set.

1.3 FHSS (verified, src/lib/FHSS/FHSS.cpp + FHSS.h)
- 2.4 GHz domain: 2400.4 MHz .. 2479.4 MHz, 80 channels, center 2440 MHz
  (fhss_config_t: name, freq_start, freq_stop, freq_count, center).
- 915 FCC domain: 903.5 .. 926.9 MHz, 40 channels, center 915 MHz.
- EU868: 863.275 .. 869.575 MHz, 13 channels.
- FHSS_SEQUENCE_LEN = 256. Hop table built once by Fisher-Yates shuffle seeded
  from a PRNG seeded with the UID (see 1.5). Hop index advances every
  FHSSopInterval packets (max 16, 4 bits in sync packet).
- Sync channel = a fixed channel used for SYNC packets & initial connection.

1.4 CRC schemes (verified)
Two distinct CRC families:

(a) CRSF (UART/serial protocol — between TX module / FC / RX). NOT the RF packet.
  src/include/crsf_protocol.h:
    CRSF_SYNC_BYTE 0xC8,  CRSF_CRC_POLY 0xD5  (CRC-8, poly 0xD5, init 0x00)
  Frame: 0xC8 | len | type | [ext dest|origin] | payload | crc8
  CRC-8 poly 0xD5 also used by MSP (msp.cpp) and SmartAudio.

(b) OTA over-air packet CRC (the one you validate on a SDR decode):
  src/lib/CRC/crc.h + crc.cpp — generic LSB-first (reflected) CRC, table-driven.
  src/lib/OTA/OTA.h:
    #define ELRS_CRC14_POLY 0x2E57   // 14-bit (Koopman implicit trailing 1)
    #define ELRS_CRC16_POLY 0x3D65   // 16-bit
  Which one is used depends on packet size (selected in OtaUpdateSerializers):
    OTA8 ("full res", 8ch / high-rate)  -> CRC16 poly 0x3D65, 16-bit
    OTA4 ("std", hybrid/wide)           -> CRC14 poly 0x2E57, 14-bit
      (14-bit is split: top 6 bits in byte0 bits6..1 "crcHigh", low 8 bits in
       the last byte "crcLow")

  CRC INITIALIZER IS NOT A CONSTANT — it is derived from the bind UID:
    src/lib/OTA/OTA.cpp  OtaUpdateCrcInitFromUid():
      OtaCrcInitializer = (UID[4] << 8) | UID[5];
      OtaCrcInitializer ^= (uint16_t)OTA_VERSION_ID << 8;
    OTA_VERSION_ID = 4  (src/include/targets.h:8)
  And the running nonce is XORed in per packet:
    nonceValidator = (type == PACKET_TYPE_SYNC) ? 0 : OtaNonce;
    crc = ota_crc.calc(pkt, CRC_CALC_LEN, OtaCrcInitializer ^ nonceValidator);

  Core CRC algorithm (port directly):
    init(bits,poly): for i in 0..255: crc=i<<(bits-8); 8x: crc=(crc<<1)^((crc&highbit)?poly:0); tab[i]=crc
    calc(data,len,crc): for each byte: crc=(crc<<8)^tab[((crc>>(bits-8))^byte)&0xFF]; return crc&mask

1.5 UID / binding phrase (the key decoding barrier)
- UID is 6 bytes. Derived from the pilot's "binding phrase":
    uid = md5(binding_phrase).digest()[0:6]
  (ExpressLRS uses md5 of the phrase; the GR repo confirms md5(...).digest()[0:6]).
- FHSS PRNG seed (src/lib/OTA/OTA.cpp OtaGetUidSeed, confirmed by GR repo):
    seed = (UID[2]<<24) | (UID[3]<<16) | (UID[4]<<8) | (UID[5]^OTA_VERSION_ID)
- FHSS PRNG (from GR repo elrs_receiver_epy_block_0.py, matches ELRS lib/FHSS/random.cpp):
    seed = (0x343FD * seed + 0x269EC3) % 0x80000000;  return seed >> 16
- Binding mode (easiest on-ramp): EnterBindingMode() (tx_main.cpp:972) sets
    OtaCrcInitializer = OTA_VERSION_ID;  OtaNonce = 0;  InvertIQ = true;
  uses a 50 Hz "binding" rate, and sends the UID over MSP (MSP_ELRS_BIND, 4 bytes).
  So during bind the CRC init is the CONSTANT OTA_VERSION_ID (4) — no UID needed.
  A bind-mode capture is the lowest-effort way to validate the whole decode chain.
- IQ inversion: `invertIQ = bindMode || (UID[5] & 0x01)` (tx_main.cpp:439,
  rx_main.cpp:312). Decoder MUST try both normal and conjugated (conjugate) I/Q.

1.6 OTA packet structures (src/lib/OTA/OTA.h)
- byte0 low 2 bits = packet type:
    PACKET_TYPE_RCDATA 0b00, PACKET_TYPE_DATA 0b01, PACKET_TYPE_SYNC 0b10
    (downlink: PACKET_TYPE_LINKSTATS 0b00)
- OTA_Packet4_s (8 bytes total): type:2|crcHigh:6 | payload(6) | crcLow
- OTA_Packet8_s (13 bytes total): type:2|stubbornAck:1|uplinkPower:3|isHighAux:1|isArmed:1
    | chLow(4x10bit) | chHigh(4x10bit) | ... | crc16 LE (2 bytes)
- OTA_Sync_s (inside SYNC packet): fhssIndex, nonce, rfRateEnum, switchEncMode:1,
    newTlmRatio:3, geminiMode:1, otaProtocol:2, free:1, UID4, UID5
  => the SYNC packet carries the current FHSS index + the last 2 UID bytes
     (UID[4],UID[5]) in the clear!
- 4x10-bit channel packing: bits A987654321 -> 87654321, 000000A9 (little-
  endianish). 10-bit CRSF value 0..1023. 16 ch in two groups (AUX2-5 / AUX6-9).

================================================================================
2. EXISTING OPEN-SOURCE REPOS
================================================================================

2.1 DIAMOND-D0GS/GNU_Radio_ExpressLRS  (★14)  <-- MOST RELEVANT
    https://github.com/Diamond-D0gs/GNU_Radio_ExpressLRS
    Full GNU Radio implementation of ExpressLRS (TX + RX). This is the primary
    "port to Python" candidate. Cloned to ./GNU_Radio_ExpressLRS.
    Key files:
      elrs_flowgraphs/reference_flowgraph.grc          (capture flowgraph)
      elrs_flowgraphs/elrs_receiver_flowgraph.grc      (decode flowgraph)
      elrs_flowgraphs/elrs_receiver.py                 (top block, 354 lines)
      elrs_flowgraphs/elrs_receiver_epy_block_0.py     (fhss_controller — PRNG+hop table)
      elrs_flowgraphs/elrs_receiver_epy_block_2.py     (Crc2Byte + OTA_Packet4 + CRC check)
      elrs_flowgraphs/cot_elrs_capture.py              (RTL/pluto capture, 915 MHz)
    NOTE: this repo is for the 915 MHz band (uses iio Pluto, fc 915 MHz).
    It uses OTA_VERSION_ID=6 in its code (newer than the 4 in current main —
    ELRS OTA version changes across releases; confirm against your target's
    ELRS version). It uses the md5(binding_phrase) UID derivation + the
    0x343FD/0x269EC3 LCG + Fisher-Yates, all in Python — directly reusable.
    The +3.7e6 "freq_temp" offsets in fhss_controller are a Pluto DC-offset
    hack, NOT part of ELRS.

2.2 uditdaftary/LoRa-ELRS-Interceptor-Decoder  (★1)  <-- ACTIVE SECURITY RESEARCH
    https://github.com/uditdaftary/LoRa-ELRS-Interceptor-Decoder
    Passive intercept + decode of ELRS 915 MHz drone control links. Full attack
    pipeline in 5 phases. Cloned to ./LoRa-ELRS-Interceptor-Decoder.
    Key files:
      README.md                                  (architecture + quickstart)
      phase0/sdr_characterize.py                 (RTL-SDR: detect SF, dechirp, FFT)
      firmware/include/elrs_common.h             (all constants: SF, BW, LCG, CRC, UIDs)
      firmware/src/phase1_net.cpp                (LoRa RX, CRC validate, SYNC hunt, UID extract)
      firmware/src/phase2_exploit.cpp            (Fisher-Yates LCG + 256-guess uid[3] brute force)
      firmware/src/phase3_lockons.cpp            (real-time hop tracking, µs timer anchor)
      firmware/src/phase4_autopsy.cpp            (dewhiten, 11-bit channel unpack)
    Method (from README):
      1. SDR characterizes SF/BW passively (phase0)
      2. Sit on ONE fixed channel; wait for the 256-length FHSS sequence to
         cross it and deliver a SYNC packet
      3. SYNC yields 3 of 4 UID bytes; brute-force the 4th (256 guesses)
      4. Rebuild hop table via Fisher-Yates/LCG, lock on in real time
      5. Decode every RC packet
    CAVEAT: some of this repo's constants are STALE/approximate vs current main
    (it uses 8-byte packets + 1-byte CRC8 poly 0x07, OTA v1/v2, LCG mult
    2891336453, sync word 0x12). It targets older ELRS. Use it for the ATTACK
    METHOD and the SDF characterization Python, but trust THIS repo's cloned
    ExpressLRS source for the exact current CRC/poly/UID/PRNG constants.

2.3 Iloke-Alusala/ELRS-ESP32-Channel-Decoder  (★38)
    https://github.com/Iloke-Alusala/ELRS-ESP32-Channel-Decoder
    Decodes CRSF (UART) on an ESP32 — NOT SDR. Good for the CRCF channel-unpack
    math (docs/theory.md has the 11-bit decode). Cloned to ./ELRS-ESP32-Channel-Decoder.
      docs/theory.md:  ch[0]=((pkt[3]|(pkt[4]<<8))&0x7FF); ch[1]=(((pkt[4]>>3)|(pkt[5]<<5))&0x7FF)
      (that's for the 16ch CRSF 0x16 frame; ELRS OTA uses the 4x10-bit pack instead)

2.4 HGSAFD8162/Expresslrs-Ghost-RX  (★12)
    https://github.com/HGSAFD8162/Expresslrs-Ghost-RX
    A passive telemetry-sniffing ELRS RX (real SX1280 radio, not SDR) based on
    ELRS 3.5.0. Useful to see how a real RX validates packets. Cloned.

2.5 Other (found, not cloned):
    sercona/rc-elrs-live-channel-display (★9)   live RC channel display from RF
    ppotepa/elrs_otg (★0)                       2.4 GHz ELRS radio detection
    Justinorange/ELRSChannelSniffer (★0)
    palia95/ELRS-Telemetry-Sniffer-Ground-Station (★0)
    Adjacent drone/SDR: lukeswitz/fpv-sdr (★89), waddyado/SkyHunter (★38),
      Genaker/LoraSA (★43), Olafseisler/dji-drone-detector (★29)

2.6 "lollipop-1": GitHub account exists but has NO ELRS/SDR repos (only flask,
    Gitrepo, op, pythonProject1). UNCONFIRMED — do not rely on it.

================================================================================
3. UHD FROM PYTHON (B210 / B205mini) — RX PATTERN
================================================================================

Canonical minimal pattern (UHD >= 4.2, `import uhd`):

  import uhd, numpy as np
  usrp = uhd.usrp_multi_usrp("type=b200,addr=192.168.10.2")   # B210/B205mini
  usrp.set_tune_request(uhd.tune_request(2.4e9))   # 2.4 GHz ELRS (or 915e6)
  usrp.set_sample_rate(4.0e6)                      # 4 MS/s (see rates above)
  usrp.set_gain(40)                                 # B210: RF 0-74 dB (+10 LNA)
  usrp.set_antenna("RX2", 0)                         # B210: RX1/RX2; B205: "RX2"

  # one-shot:
  samples = usrp.get_samples(1<<20)                  # complex64

  # streaming:
  args = uhd.stream_args("fc32", "")                 # fc32 = 32-bit float complex
  usrp.set_stream_args(args)
  st = usrp.get_rx_stream()
  while True:
      buf = np.zeros(4096, np.complex64)
      m = uhd.rx_metadata()
      n = st.recv(buf, 4096, uhd.timeout(0.1), m)
      process(buf[:n])

Key points:
- IQ format: fc32 (default, easiest) or sc16 (int16, lower BW).
- Sample rate: 2.4 GHz LoRa@800kHz -> 4-8 MS/s; 915 LoRa@500kHz -> 2.5-4 MS/s.
- B210: two RX chains + 10 dB LNA (set_rx_lna? via set_gain / "lfgain"); B205mini:
  one chain, no separate LNA. Query get_antenna_names(0) before set_antenna.
- FHSS: single center freq only catches one hop. Either (a) capture wide
  (6-10 MS/s) mid-band + per-hop FFT detection, or (b) lock the hop table from a
  SYNC packet and follow. Start with wide capture + peak hunting.
- Polarity: try normal AND conjugated I/Q (InvertIQ logic, 1.5).
- LoRa demod: use a LoRa demod (gr-lora / sdr-lora / a custom dechirp-FFT as in
  phase0/sdr_characterize.py) — LoRa is NOT a plain GFSK demod.

NOTE: not executed here (no UHD/SDR on the analysis box); standard reference to
verify against installed `uhd` version before running on real hardware.

================================================================================
4. GNU RADIO FLOWGRAPHS FOR ELRS
================================================================================
- YES: Diamond-D0gs/GNU_Radio_ExpressLRS ships GRC flowgraphs:
    reference_flowgraph.grc, elrs_receiver_flowgraph.grc, elrs_transmitter_flowgraph.grc
  plus compiled .py top blocks (elrs_receiver.py, etc.) and epy blocks with the
  actual decode logic (Crc2Byte, OTA structs, FHSS PRNG). These are the port
  source: lift the epy-block Python (Crc2Byte.calc, OTA_Packet4_s, the LCG +
  Fisher-Yates, the md5-UID) into a pure-Python UHD pipeline (skip GR entirely).
- No other dedicated ELRS GRC repo surfaced (queries "elrs uhd", "elrs gqrx",
  "crsf sdr", "expresslrs gnu radio" -> only the Diamond-D0gs repo).

================================================================================
PORT PLAN (Python + UHD, no GNU Radio) — recommended
================================================================================
1. Capture: UHD B210/B205, wide-band IQ (4-8 MS/s) over 2.4 GHz (or 915 MHz),
   save to .cfile/.sc16.
2. LoRa demod per hop (dechirp-FFT, both polarities). Preamble detect on each
   hop window.
3. Grab a SYNC packet -> read fhssIndex + UID[4],UID[5] in clear.
4. Get UID[2..3] (from binding-phrase md5 if you know the phrase, else brute
   force 2^16 candidates) -> build seed -> LCG + Fisher-Yates -> full 256-hop
   table -> follow FHSS.
5. Validate each RC packet: Crc2Byte (16-bit 0x3D65 for OTA8 / 14-bit 0x2E57
   for OTA4) with init = (UID[4]<<8|UID[5]) ^ (OTA_VERSION_ID<<8) ^ nonce.
6. Unpack 4x10-bit channels (little-endianish) -> RC.
Lowest-effort validation path: capture BIND mode (50 Hz, InvertIQ, CRC init =
OTA_VERSION_ID constant) and prove the chain before tackling a live bound link.
