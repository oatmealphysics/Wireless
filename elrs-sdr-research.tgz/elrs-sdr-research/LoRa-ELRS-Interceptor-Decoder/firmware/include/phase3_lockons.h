#pragma once
/**
 * firmware/include/phase3_lockons.h
 * ───────────────────────────────────
 * Phase 3: The Lock-On — real-time FHSS tracking with dead-reckoning
 */

#include "elrs_common.h"

/**
 * Start the synchronized hop task.
 * Must be called after Phase 2 has populated hop_state.
 *
 * @param hop_state   fully populated hop state from phase2_brute_force()
 * @param out_frame   pointer to rc_frame_t that phase4 writes into
 */
void phase3_start(hop_state_t *hop_state, rc_frame_t *out_frame);

/**
 * FreeRTOS task — Phase 3 main loop.
 * Hops the LR1121 in sync with the drone every HOP_INTERVAL_US µs.
 * Uses hardware timer anchor for deterministic timing.
 * Calls phase4 decode on every received packet.
 * Dead-reckons on missed packets up to MAX_MISSED_PACKETS.
 * Falls back to Phase 1 after MAX_MISSED_PACKETS consecutive misses.
 */
void phase3_task(void *pvParameters);
