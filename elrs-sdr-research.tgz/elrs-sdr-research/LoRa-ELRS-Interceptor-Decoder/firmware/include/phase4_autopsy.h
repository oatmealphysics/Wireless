#pragma once
/**
 * firmware/include/phase4_autopsy.h
 * ───────────────────────────────────
 * Phase 4: The Autopsy — dewhiten, 11-bit channel unpack, output
 */

#include "elrs_common.h"

/**
 * Reverse the ELRS payload whitening.
 * Must be called BEFORE channel unpacking.
 *
 * Whitening is an RF physics requirement — not encryption.
 * Long runs of identical bits cause hardware clock drift and DC bias.
 * The LFSR guarantees a statistically balanced bitstream.
 *
 * Skipping this step causes channel values to read as apparent noise
 * even though CRC passes (CRC is computed on the whitened payload).
 *
 * @param payload   raw payload bytes (modified in-place)
 * @param len       number of payload bytes (excludes CRC byte)
 * @param uid       complete 4-byte UID (all bytes known after Phase 2)
 */
void phase4_dewhiten(uint8_t *payload, uint8_t len, const elrs_uid_t *uid);

/**
 * Unpack 16 RC channels from the dewhitened payload.
 * Channels are bit-packed: 16 × 11 bits = 176 bits = 22 bytes.
 * Values: 0–2047, center = 1024.
 *
 * @param payload   dewhitened payload bytes
 * @param channels  output array of N_CHANNELS uint16_t
 */
void phase4_unpack_channels(const uint8_t *payload, uint16_t *channels);

/**
 * Map raw channel values to a human-readable rc_frame_t.
 * Sets frame->armed and frame->active detection flags.
 */
void phase4_map_frame(const uint16_t *channels, rc_frame_t *frame);

/**
 * Full decode pipeline: dewhiten → unpack → map.
 * Operates on a copy of the payload (does not modify buf).
 *
 * @param buf       full packet buffer (including CRC byte)
 * @param buf_len   total buffer length
 * @param uid       complete UID
 * @param frame     output rc_frame_t
 */
void phase4_decode_packet(const uint8_t *buf, uint8_t buf_len,
                           const elrs_uid_t *uid, rc_frame_t *frame);

/**
 * Print decoded frame to UART (115200 baud).
 * Format: [PHASE4] ACTIVE | Throttle: 68% | Roll: +12° | ...
 */
void phase4_print_frame(const rc_frame_t *frame);
