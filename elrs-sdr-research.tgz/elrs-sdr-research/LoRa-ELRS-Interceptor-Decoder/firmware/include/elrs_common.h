#pragma once
/**
 * firmware/include/elrs_common.h
 * ───────────────────────────────
 * Shared constants, types, pin assignments, and state definitions
 * for the ELRS interceptor firmware.
 *
 * EDIT BEFORE FLASHING:
 *   ELRS_SF  — set from phase0/sdr_characterize.py output
 */

#include <stdint.h>
#include <stdbool.h>

// ── Pin Assignments (ESP32 → LR1121) ─────────────────────────────────────────
#define PIN_SCK       18
#define PIN_MISO      19
#define PIN_MOSI      23
#define PIN_NSS        5    // SPI chip select
#define PIN_DIO1      26    // hardware interrupt — packet ready
#define PIN_NRESET    14    // hardware reset

// ── SPI Configuration ─────────────────────────────────────────────────────────
#define SPI_FREQ_HZ   16000000UL    // 16 MHz — maximize payload drain speed

// ── LoRa Physical Layer (ELRS 900 MHz) ───────────────────────────────────────
//   All constants sourced from ExpressLRS open-source repository.
//   Ref: ELRS/src/lib/SX126XDriver/SX126XDriver.cpp
#define ELRS_SYNC_WORD      0x12    // Semtech private network sync word
#define ELRS_BW_KHZ         500     // bandwidth — fixed across all ELRS 900 modes
#define ELRS_CODING_RATE    5       // 4/5 coding rate

// ► SET THIS FROM sdr_characterize.py OUTPUT:
#define ELRS_SF             7       // spreading factor (6–10)

// ── Derived Timing ────────────────────────────────────────────────────────────
// Symbol duration (µs) = (2^SF / BW_Hz) * 1e6
#define ELRS_SYM_DUR_US     ((1 << ELRS_SF) * 1000000UL / (ELRS_BW_KHZ * 1000UL))
// Hop interval ≈ one packet duration + processing margin
#define HOP_INTERVAL_US     (ELRS_SYM_DUR_US * 12UL)   // ~preamble + header + payload

// ── FHSS Parameters ───────────────────────────────────────────────────────────
// Ref: ELRS/src/lib/FHSS/FHSS.cpp
#define ELRS_FREQ_BASE_HZ   903500000UL   // lowest ELRS 900 channel (US FCC)
#define ELRS_FREQ_STEP_HZ     500000UL    // 500 kHz channel spacing
#define ELRS_N_FREQ              13       // number of hop channels

// LCG constants for Fisher-Yates hop table generation
#define ELRS_LCG_MULT       2891336453UL
#define ELRS_LCG_INC        1UL

// ── Whitening LFSR ────────────────────────────────────────────────────────────
// Ref: ELRS/src/lib/FHSS/FHSS.cpp
#define ELRS_LFSR_POLY      0x69

// ── Packet Types (ELRS OTA) ───────────────────────────────────────────────────
#define PKT_TYPE_RC         0x00    // RC channel data
#define PKT_TYPE_SYNC       0x01    // SYNC packet — contains UID
#define PKT_TYPE_MSPV2      0x02    // MSP passthrough
#define PKT_TYPE_TLM        0x03    // telemetry uplink

// ── OTA Versions ─────────────────────────────────────────────────────────────
#define OTA_VERSION_1       1       // ELRS < 3.x
#define OTA_VERSION_2       2       // ELRS >= 3.x (current)

// UID byte offset within SYNC packet payload (differs by OTA version)
#define OTA_V1_UID_OFFSET   2
#define OTA_V2_UID_OFFSET   3

// ── Packet Sizes ─────────────────────────────────────────────────────────────
#define ELRS_PACKET_SIZE    8       // bytes (OTA v2 RC packet)
#define ELRS_CRC_SIZE       1       // CRC byte appended at end
#define ELRS_PAYLOAD_SIZE   (ELRS_PACKET_SIZE - ELRS_CRC_SIZE)

// ── RC Channel Mapping ───────────────────────────────────────────────────────
#define CH_ROLL             0
#define CH_PITCH            1
#define CH_THROTTLE         2
#define CH_YAW              3
#define CH_ARM              4
#define CH_FLIGHT_MODE      5
#define N_CHANNELS          16
#define CH_CENTER           1024    // 11-bit center value
#define CH_MIN              0
#define CH_MAX              2047
#define ARM_THRESHOLD       1500    // ch > this = armed
#define STICK_DEADBAND      50      // movement detection threshold

// ── Re-Sync Parameters ───────────────────────────────────────────────────────
#define MAX_MISSED_PACKETS  4       // missed packets before fallback to HUNTING

// ── CRC ───────────────────────────────────────────────────────────────────────
#define CRC8_POLY           0x07
#define CRC8_INIT           0x00

// ── Interceptor State Machine ─────────────────────────────────────────────────
typedef enum {
    STATE_HUNTING   = 0,    // Phase 1: waiting for SYNC packet
    STATE_EXPLOITING,       // Phase 2: brute forcing uid[3]
    STATE_LOCKED,           // Phase 3+4: synchronized hopping + decoding
} interceptor_state_t;

// ── UID Type ──────────────────────────────────────────────────────────────────
typedef struct {
    uint8_t bytes[4];
    bool    complete;       // true once uid[3] brute forced
} elrs_uid_t;

// ── Decoded RC Frame ──────────────────────────────────────────────────────────
typedef struct {
    uint16_t channels[N_CHANNELS];
    bool     armed;
    bool     active;
    uint8_t  flight_mode;
} rc_frame_t;

// ── Hop State ─────────────────────────────────────────────────────────────────
typedef struct {
    uint32_t table[ELRS_N_FREQ];    // frequency list in hop order
    uint8_t  index;                 // current position in sequence
    uint64_t t_anchor;              // hardware µs timestamp of last sync
    uint8_t  missed;                // consecutive missed packets
} hop_state_t;
