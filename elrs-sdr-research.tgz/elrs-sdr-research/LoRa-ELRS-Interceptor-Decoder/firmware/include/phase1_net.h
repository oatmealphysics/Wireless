#pragma once
/**
 * firmware/include/phase1_net.h
 * ──────────────────────────────
 * Phase 1: The Net — LR1121 init, CRC validation, OTA detection, UID extraction
 */

#include "elrs_common.h"

/**
 * Initialise the LR1121 radio over SPI.
 * Sets frequency, BW, SF, sync word, and enters continuous RX.
 * Returns true on success.
 */
bool phase1_radio_init(void);

/**
 * Attach the DIO1 hardware interrupt.
 * The ISR notifies phase1_task via FreeRTOS direct task notification.
 */
void phase1_attach_interrupt(void);

/**
 * CRC8/CCITT (poly 0x07, init 0x00) over `len` bytes.
 * Pass the full payload excluding the CRC byte.
 */
uint8_t crc8_ccitt(const uint8_t *data, uint8_t len);

/**
 * Validate a received packet buffer.
 * Checks CRC: buf[0..ELRS_PAYLOAD_SIZE-1] against buf[ELRS_PAYLOAD_SIZE].
 * Returns true if packet is genuine.
 */
bool phase1_validate_crc(const uint8_t *buf, uint8_t total_len);

/**
 * Detect OTA version from packet header bits [7:6].
 * Returns OTA_VERSION_1 or OTA_VERSION_2.
 * Returns 0 on unknown version (discard packet).
 */
uint8_t phase1_detect_ota_version(const uint8_t *buf);

/**
 * Extract packet type from header.
 * Returns PKT_TYPE_RC, PKT_TYPE_SYNC, etc.
 */
uint8_t phase1_get_packet_type(const uint8_t *buf);

/**
 * Extract 3 known UID bytes from a validated SYNC packet.
 * uid->bytes[3] is left at 0x00 (unknown — brute forced in Phase 2).
 * uid->complete is set to false.
 * Returns false if OTA version is unrecognised.
 */
bool phase1_extract_uid(const uint8_t *buf, elrs_uid_t *uid);

/**
 * FreeRTOS task — Phase 1 main loop.
 * Sits on fixed channel, waits for DIO1 interrupt, validates packets,
 * hunts for a SYNC packet, then signals Phase 2 with captured UID.
 */
void phase1_task(void *pvParameters);
