/**
 * firmware/src/phase3_lockons.cpp
 * ─────────────────────────────────
 * Phase 3: The Lock-On
 *
 * Once the seed is confirmed, this task becomes the real-time core
 * of the interceptor. Every HOP_INTERVAL_US microseconds, it must:
 *
 *   1. Increment hop index
 *   2. Command the LR1121 to the next frequency (SPI write)
 *   3. Start RX
 *   4. Wait for DIO1 interrupt or timeout
 *   5. If packet → forward to Phase 4 decode
 *   6. If miss → dead-reckon (advance index, update anchor)
 *   7. If too many misses → fall back to Phase 1
 *
 * The hardware µs timer (esp_timer_get_time) is the synchronisation
 * backbone. Every future hop is computed as a strict offset from t_anchor.
 * This prevents cumulative drift.
 *
 * FreeRTOS requirement: this task must run at the HIGHEST priority of all
 * application tasks. Python/MicroPython GC stalls would violate the 2ms
 * window at F500. C + FreeRTOS + IRAM ISR keeps total latency < 100 µs.
 */

#include "phase3_lockons.h"
#include "phase4_autopsy.h"
#include "phase1_net.h"
#include "elrs_common.h"

#include <RadioLib.h>
#include <esp_log.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

static const char *TAG = "PHASE3";

extern SX1262 radio;
extern TaskHandle_t g_phase1_task_handle;
extern TaskHandle_t g_main_task_handle;

// Shared between ISR and phase3_task
static volatile TaskHandle_t s_phase3_task_handle = NULL;
static volatile bool         s_packet_ready       = false;


// ── DIO1 ISR (Phase 3 version) ────────────────────────────────────────────────
// Re-registered when Phase 3 starts to notify the hop task directly.

static void IRAM_ATTR phase3_dio1_isr(void *arg) {
    s_packet_ready = true;
    BaseType_t woken = pdFALSE;
    vTaskNotifyGiveFromISR((TaskHandle_t)s_phase3_task_handle, &woken);
    portYIELD_FROM_ISR(woken);
}


// ── Timing Helper ─────────────────────────────────────────────────────────────

/**
 * Busy-spin until target µs timestamp.
 * esp_rom_delay_us for sub-tick precision; vTaskDelay only for delays > 1ms
 * to avoid starving other tasks on the same core.
 */
static inline void wait_until(uint64_t target_us) {
    int64_t remaining = (int64_t)target_us - (int64_t)esp_timer_get_time();
    if (remaining > 1000) {
        vTaskDelay(pdMS_TO_TICKS(remaining / 1000 - 1));
    }
    // Spin for the last sub-millisecond
    while (esp_timer_get_time() < target_us) { /* busy wait */ }
}


// ── Phase 3 Start ─────────────────────────────────────────────────────────────

void phase3_start(hop_state_t *hop_state, rc_frame_t *out_frame) {
    // Pack both pointers into a single struct passed to the task
    static struct { hop_state_t *hs; rc_frame_t *rf; } params;
    params.hs = hop_state;
    params.rf = out_frame;

    xTaskCreatePinnedToCore(
        phase3_task,
        "phase3_hop",
        4096,
        &params,
        configMAX_PRIORITIES - 1,   // highest priority
        (TaskHandle_t *)&s_phase3_task_handle,
        1                           // pin to core 1 (core 0 = WiFi/BT)
    );
}


// ── Phase 3 Task ──────────────────────────────────────────────────────────────

void phase3_task(void *pvParameters) {
    auto *p        = (struct { hop_state_t *hs; rc_frame_t *rf; } *)pvParameters;
    hop_state_t *hop   = p->hs;
    rc_frame_t  *frame = p->rf;

    s_phase3_task_handle = xTaskGetCurrentTaskHandle();

    // Re-attach DIO1 ISR to notify THIS task
    gpio_isr_handler_remove((gpio_num_t)PIN_DIO1);
    gpio_isr_handler_add((gpio_num_t)PIN_DIO1, phase3_dio1_isr, NULL);

    uint8_t buf[ELRS_PACKET_SIZE];

    ESP_LOGI(TAG, "[PHASE3] Lock-on. Hopping every %llu µs. "
             "Anchor t=0 at index %u.", HOP_INTERVAL_US, hop->index);

    for (;;) {
        hop->index = (hop->index + 1) % ELRS_N_FREQ;

        // Compute absolute deadline for NEXT hop BEFORE tuning
        uint64_t next_hop_time = hop->t_anchor
                               + ((uint64_t)hop->index * HOP_INTERVAL_US);

        // Tune LR1121 to current hop frequency (SPI: ~5–10 µs at 16 MHz)
        radio.setFrequency((float)hop->table[hop->index] / 1e6f);
        radio.startReceive();
        s_packet_ready = false;

        // ── Wait for packet or deadline ───────────────────────────────────────
        uint32_t notified = ulTaskNotifyTake(pdTRUE,
            pdMS_TO_TICKS((HOP_INTERVAL_US / 1000) + 1));

        if (notified && s_packet_ready) {
            // ── Packet received ───────────────────────────────────────────────
            int state = radio.readData(buf, ELRS_PACKET_SIZE);

            if (state == RADIOLIB_ERR_NONE
                && phase1_validate_crc(buf, ELRS_PACKET_SIZE)
                && phase1_get_packet_type(buf) == PKT_TYPE_RC) {

                hop->missed = 0;

                // Decode in Phase 4 (runs inline — fast, no task switch needed)
                phase4_decode_packet(buf, ELRS_PACKET_SIZE,
                                     (elrs_uid_t *)&g_captured_uid, frame);
                phase4_print_frame(frame);
            }
        } else {
            // ── Miss — dead-reckoning ─────────────────────────────────────────
            hop->missed++;

            if (hop->missed > MAX_MISSED_PACKETS) {
                ESP_LOGW(TAG, "Too many misses (%u). Falling back to Phase 1.",
                         hop->missed);
                hop->missed = 0;

                // Notify main state machine
                xTaskNotify(g_main_task_handle, (uint32_t)STATE_HUNTING,
                            eSetValueWithOverwrite);

                // Resume Phase 1 task (was suspended after SYNC capture)
                vTaskResume(g_phase1_task_handle);

                // Suspend self — will be deleted/restarted by main on re-lock
                vTaskSuspend(NULL);
            } else {
                // Dead-reckon: advance anchor as if the drone hopped normally
                hop->t_anchor += HOP_INTERVAL_US;
                ESP_LOGD(TAG, "Miss %u/%u — dead-reckoning",
                         hop->missed, MAX_MISSED_PACKETS);
            }
        }

        // Wait until the precise moment to issue the next tune command
        wait_until(next_hop_time);
    }
}
