/**
 * firmware/src/phase4_autopsy.cpp
 * ─────────────────────────────────
 * Phase 4: The Autopsy
 *
 * Final stage of the decode pipeline:
 *   raw packet bytes
 *     → dewhiten (LFSR XOR)
 *       → unpack 16 × 11-bit RC channels
 *         → map to human-readable frame
 *           → print to UART
 *
 * Call order is strictly enforced:
 *   CRC validate (Phase 1) → dewhiten → unpack → map
 *
 * The dewhiten step MUST come before channel unpacking.
 * CRC is computed over the WHITENED payload, so a CRC pass does NOT
 * mean the payload is ready to parse. You must reverse the whitening first.
 */

#include "phase4_autopsy.h"
#include "elrs_common.h"

#include <esp_log.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

static const char *TAG = "PHASE4";


// ── Dewhitening ───────────────────────────────────────────────────────────────

void phase4_dewhiten(uint8_t *payload, uint8_t len, const elrs_uid_t *uid) {
    // LFSR seed: XOR of uid[0] and uid[3]
    // Ref: ELRS/src/lib/FHSS/FHSS.cpp — FHSSwhiten()
    uint8_t lfsr = uid->bytes[0] ^ uid->bytes[3];

    for (uint8_t i = 0; i < len; i++) {
        payload[i] ^= lfsr;
        // Advance LFSR: feedback polynomial 0x69
        lfsr = (lfsr >> 1) ^ (ELRS_LFSR_POLY * (lfsr & 1));
    }
}


// ── Channel Unpack ────────────────────────────────────────────────────────────

void phase4_unpack_channels(const uint8_t *payload, uint16_t *channels) {
    // 16 channels × 11 bits = 176 bits = 22 bytes, little-endian bit order
    int bit_pos = 0;

    for (int i = 0; i < N_CHANNELS; i++) {
        uint16_t val = 0;
        for (int b = 0; b < 11; b++) {
            uint8_t byte_idx = bit_pos >> 3;          // bit_pos / 8
            uint8_t bit_idx  = bit_pos & 0x07;        // bit_pos % 8
            val |= (uint16_t)((payload[byte_idx] >> bit_idx) & 1) << b;
            bit_pos++;
        }
        channels[i] = val;   // 0–2047
    }
}


// ── Frame Mapping ─────────────────────────────────────────────────────────────

void phase4_map_frame(const uint16_t *channels, rc_frame_t *frame) {
    for (int i = 0; i < N_CHANNELS; i++) {
        frame->channels[i] = channels[i];
    }

    frame->armed       = (channels[CH_ARM] > ARM_THRESHOLD);
    frame->flight_mode = (uint8_t)(channels[CH_FLIGHT_MODE] / 204);  // 0–9 range

    // Active = armed AND (throttle above idle OR any stick outside deadband)
    bool throttle_live = (channels[CH_THROTTLE] > 200);
    bool sticks_live   = (abs((int)channels[CH_ROLL]  - CH_CENTER) > STICK_DEADBAND)
                      || (abs((int)channels[CH_PITCH] - CH_CENTER) > STICK_DEADBAND)
                      || (abs((int)channels[CH_YAW]   - CH_CENTER) > STICK_DEADBAND);

    frame->active = frame->armed && (throttle_live || sticks_live);
}


// ── Full Decode Pipeline ──────────────────────────────────────────────────────

void phase4_decode_packet(const uint8_t *buf, uint8_t buf_len,
                           const elrs_uid_t *uid, rc_frame_t *frame) {
    // Work on a local copy — do not modify the original buffer
    uint8_t payload[ELRS_PAYLOAD_SIZE];
    uint8_t copy_len = (buf_len > ELRS_PAYLOAD_SIZE) ? ELRS_PAYLOAD_SIZE : buf_len - 1;
    memcpy(payload, buf + 1, copy_len);  // skip header byte, stop before CRC

    // Step 1: Dewhiten (RF conditioning reversal)
    phase4_dewhiten(payload, copy_len, uid);

    // Step 2: Unpack 11-bit channels
    uint16_t channels[N_CHANNELS];
    phase4_unpack_channels(payload, channels);

    // Step 3: Map to frame
    phase4_map_frame(channels, frame);
}


// ── UART Output ───────────────────────────────────────────────────────────────

/**
 * Convert a raw channel value (0–2047) to a signed percentage (-100 to +100).
 * Center (1024) maps to 0%.
 */
static int ch_to_pct(uint16_t val) {
    return (int)(((int)val - CH_CENTER) * 100 / CH_CENTER);
}

/**
 * Convert throttle (0–2047) to unsigned percentage (0–100).
 */
static int throttle_pct(uint16_t val) {
    return (int)((uint32_t)val * 100 / CH_MAX);
}

void phase4_print_frame(const rc_frame_t *frame) {
    if (!frame->active) {
        // Suppress idle / disarmed frames to reduce log noise
        // Remove this guard if you need to log all frames
        if (!frame->armed) return;
    }

    int  thr  = throttle_pct(frame->channels[CH_THROTTLE]);
    int  roll = ch_to_pct(frame->channels[CH_ROLL]);
    int  pit  = ch_to_pct(frame->channels[CH_PITCH]);
    int  yaw  = ch_to_pct(frame->channels[CH_YAW]);

    const char *arm_str  = frame->armed  ? "ARMED"    : "DISARMED";
    const char *act_str  = frame->active ? "ACTIVE"   : "IDLE";

    // Directional labels
    const char *roll_dir = (roll > STICK_DEADBAND/10) ? "right"
                         : (roll < -STICK_DEADBAND/10) ? "left" : "centre";
    const char *pit_dir  = (pit  > STICK_DEADBAND/10) ? "fwd"
                         : (pit  < -STICK_DEADBAND/10) ? "back" : "level";

    ESP_LOGI(TAG, "%s | Thr: %3d%% | Roll: %+4d%% (%s) | "
             "Pitch: %+4d%% (%s) | Yaw: %+4d%% | %s | Mode: %u",
             act_str, thr, roll, roll_dir, pit, pit_dir, yaw,
             arm_str, frame->flight_mode);
}
