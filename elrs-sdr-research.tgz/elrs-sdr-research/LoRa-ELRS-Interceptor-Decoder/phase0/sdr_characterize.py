#!/usr/bin/env python3
"""
phase0/sdr_characterize.py
──────────────────────────
ELRS Interceptor — Phase 0: Passive SDR Characterization

Run this ONCE on a laptop with an RTL-SDR before deploying the ESP32 firmware.
Scans the 902–928 MHz band, detects LoRa chirps, measures symbol duration,
and derives the Spreading Factor (SF) in use.

Output is the SF value to paste into firmware/include/elrs_common.h

Dependencies:
    pip install numpy scipy pyrtlsdr matplotlib

Usage:
    python sdr_characterize.py [--freq 915e6] [--plot]
"""

import argparse
import time
import numpy as np
from scipy import signal

try:
    import rtlsdr
    SDR_AVAILABLE = True
except ImportError:
    SDR_AVAILABLE = False
    print("[WARN] pyrtlsdr not installed. Running in simulation mode.")


# ── Constants ────────────────────────────────────────────────────────────────

ELRS_BW_HZ       = 500_000          # ELRS 900 bandwidth — always 500 kHz
SCAN_CENTER_HZ   = 915_000_000      # centre of ELRS 900 regulatory band
SCAN_BW_HZ       = 2_400_000        # RTL-SDR capture bandwidth (~2.4 MHz)
SAMPLE_RATE      = 2_400_000        # samples/sec
CAPTURE_SECONDS  = 2.0              # seconds of IQ to capture
N_SAMPLES        = int(SAMPLE_RATE * CAPTURE_SECONDS)

# ELRS SF → expected symbol duration at 500 kHz BW
SF_TABLE = {
    6:  (2**6)  / ELRS_BW_HZ,   # 128 µs  → 500 Hz  (F500)
    7:  (2**7)  / ELRS_BW_HZ,   # 256 µs  → 250 Hz  (F250)
    8:  (2**8)  / ELRS_BW_HZ,   # 512 µs  → 150 Hz  (F150)
    9:  (2**9)  / ELRS_BW_HZ,   # 1024 µs → 50 Hz   (F50)
    10: (2**10) / ELRS_BW_HZ,   # 2048 µs → 25 Hz   (F25)
}

PACKET_RATE = {6: 500, 7: 250, 8: 150, 9: 50, 10: 25}
HOP_WINDOW  = {6: 2000, 7: 4000, 8: 6700, 9: 20000, 10: 40000}   # µs


# ── SDR Capture ───────────────────────────────────────────────────────────────

def capture_iq(center_freq: float, sample_rate: int, n_samples: int) -> np.ndarray:
    """Capture raw IQ samples from RTL-SDR."""
    sdr = rtlsdr.RtlSdr()
    sdr.sample_rate   = sample_rate
    sdr.center_freq   = center_freq
    sdr.freq_correction = 60          # PPM correction — tune for your dongle
    sdr.gain          = 'auto'
    print(f"[SDR] Capturing {n_samples / sample_rate:.1f}s at {center_freq/1e6:.3f} MHz ...")
    samples = sdr.read_samples(n_samples)
    sdr.close()
    return samples.astype(np.complex64)


def simulate_iq(sf: int = 7) -> np.ndarray:
    """Simulate a LoRa chirp signal for testing without hardware."""
    sym_dur   = (2**sf) / ELRS_BW_HZ
    n_sym     = int(sym_dur * SAMPLE_RATE)
    t         = np.linspace(0, sym_dur, n_sym, endpoint=False)
    # Up-chirp: instantaneous freq sweeps from -BW/2 to +BW/2
    chirp_sig = np.exp(1j * 2 * np.pi * (-ELRS_BW_HZ/2 * t + ELRS_BW_HZ / (2 * sym_dur) * t**2))
    # 12 preamble symbols + noise
    preamble  = np.tile(chirp_sig, 12)
    noise     = (np.random.randn(len(preamble)) + 1j * np.random.randn(len(preamble))) * 0.3
    # Offset carrier by +200 kHz to simulate real-world CFO
    cfo_hz    = 200_000
    t_total   = np.arange(len(preamble)) / SAMPLE_RATE
    preamble  = preamble * np.exp(2j * np.pi * cfo_hz * t_total)
    padding   = np.zeros(N_SAMPLES - len(preamble), dtype=np.complex64)
    return np.concatenate([preamble + noise, padding]).astype(np.complex64)


# ── Channelization (CFO correction) ──────────────────────────────────────────

def channelize(iq: np.ndarray, signal_freq_hz: float, center_freq_hz: float,
               sample_rate: int) -> np.ndarray:
    """
    Mix the captured IQ down to baseband centered on the detected signal.

    Critical: chirp dechirping only works correctly when the signal is at 0 Hz.
    Without this step, the FFT peak after dechirping encodes BOTH the sync word
    nibble AND the carrier frequency offset — giving garbage.
    """
    cfo_hz = signal_freq_hz - center_freq_hz
    t      = np.arange(len(iq)) / sample_rate
    iq_bb  = iq * np.exp(-2j * np.pi * cfo_hz * t)

    # Low-pass filter to isolate the 500 kHz channel
    nyq     = sample_rate / 2
    cutoff  = (ELRS_BW_HZ * 0.6) / nyq      # slight margin above BW
    b, a    = signal.butter(5, cutoff, btype='low')
    return signal.lfilter(b, a, iq_bb).astype(np.complex64)


# ── Signal Detection ──────────────────────────────────────────────────────────

def detect_lora_signal(iq: np.ndarray, sample_rate: int) -> tuple[bool, float]:
    """
    Detect LoRa signal presence using energy in the chirp band.
    Returns (detected, estimated_signal_offset_hz).
    """
    freqs   = np.fft.fftfreq(len(iq), d=1/sample_rate)
    psd     = np.abs(np.fft.fft(iq))**2
    psd_db  = 10 * np.log10(psd + 1e-12)
    noise_floor = np.percentile(psd_db, 30)
    peak_idx    = np.argmax(psd_db)
    peak_db     = psd_db[peak_idx]
    snr         = peak_db - noise_floor
    offset_hz   = freqs[peak_idx]
    return (snr > 8.0), float(offset_hz)


# ── SF Measurement ────────────────────────────────────────────────────────────

def generate_reference_chirp(sf: int, sample_rate: int) -> np.ndarray:
    """Generate an ideal LoRa up-chirp for the given SF at 500 kHz BW."""
    sym_dur = (2**sf) / ELRS_BW_HZ
    n       = int(sym_dur * sample_rate)
    t       = np.linspace(0, sym_dur, n, endpoint=False)
    return np.exp(1j * 2 * np.pi * (-ELRS_BW_HZ/2 * t + ELRS_BW_HZ / (2*sym_dur) * t**2))


def measure_sf(iq_bb: np.ndarray, sample_rate: int) -> int:
    """
    Determine SF by cross-correlating against all candidate reference chirps.
    The SF whose reference chirp best matches the signal wins.

    This works because each SF produces a distinct symbol duration.
    Correlation peak amplitude is maximised when durations match exactly.
    """
    best_sf    = -1
    best_score = -np.inf

    for sf, sym_dur in SF_TABLE.items():
        ref      = generate_reference_chirp(sf, sample_rate)
        n_sym    = len(ref)

        if n_sym > len(iq_bb):
            continue

        # Slide correlation over first few symbols
        scores = []
        for start in range(0, min(len(iq_bb) - n_sym, n_sym * 8), n_sym):
            window   = iq_bb[start:start + n_sym]
            dechirp  = window * np.conj(ref)
            fft_out  = np.abs(np.fft.fft(dechirp))
            peak     = np.max(fft_out)
            noise    = np.mean(fft_out)
            scores.append(peak / (noise + 1e-9))

        score = np.median(scores) if scores else 0.0
        print(f"  SF{sf:2d}  sym_dur={sym_dur*1e6:.0f}µs  score={score:.2f}")

        if score > best_score:
            best_score = score
            best_sf    = sf

    return best_sf


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="ELRS Phase 0 — SDR Characterization")
    parser.add_argument("--freq",   type=float, default=SCAN_CENTER_HZ,
                        help="SDR centre frequency in Hz (default: 915e6)")
    parser.add_argument("--plot",   action="store_true",
                        help="Show waterfall plot (requires matplotlib)")
    parser.add_argument("--sim",    action="store_true",
                        help="Run in simulation mode (no SDR hardware)")
    parser.add_argument("--sim-sf", type=int, default=7,
                        help="SF to simulate (default: 7)")
    args = parser.parse_args()

    print("=" * 60)
    print("  ELRS Interceptor — Phase 0: SDR Characterization")
    print("=" * 60)

    # ── Capture ──────────────────────────────────────────────────────────────
    if args.sim or not SDR_AVAILABLE:
        print(f"[SIM] Generating synthetic SF{args.sim_sf} signal...")
        iq_raw      = simulate_iq(sf=args.sim_sf)
        signal_freq = args.freq + 200_000    # simulated CFO
    else:
        iq_raw      = capture_iq(args.freq, SAMPLE_RATE, N_SAMPLES)
        detected, signal_offset = detect_lora_signal(iq_raw, SAMPLE_RATE)
        if not detected:
            print("[WARN] No LoRa signal detected. Is the drone active?")
            print("       Running SF analysis anyway...")
        signal_freq = args.freq + signal_offset
        print(f"[SDR] Signal detected at offset {signal_offset/1e3:+.1f} kHz")

    # ── CFO Correction ───────────────────────────────────────────────────────
    print(f"[CFO] Mixing down: {signal_freq/1e6:.3f} MHz → 0 Hz baseband")
    iq_bb = channelize(iq_raw, signal_freq, args.freq, SAMPLE_RATE)

    # ── SF Measurement ───────────────────────────────────────────────────────
    print("\n[SF]  Correlating against reference chirps...")
    sf = measure_sf(iq_bb, SAMPLE_RATE)

    if sf < 0:
        print("\n[ERR] Could not determine SF. Check signal strength.")
        return

    # ── Waterfall (optional) ─────────────────────────────────────────────────
    if args.plot:
        try:
            import matplotlib.pyplot as plt
            f, t_spec, Sxx = signal.spectrogram(iq_raw, fs=SAMPLE_RATE,
                                                 nperseg=512, noverlap=480,
                                                 return_onesided=False)
            f_mhz = (np.fft.fftshift(f) + args.freq) / 1e6
            plt.figure(figsize=(12, 5))
            plt.pcolormesh(t_spec, np.fft.fftshift(f_mhz),
                           10 * np.log10(np.fft.fftshift(Sxx, axes=0) + 1e-12),
                           shading='auto', cmap='inferno')
            plt.colorbar(label='Power (dB)')
            plt.xlabel('Time (s)')
            plt.ylabel('Frequency (MHz)')
            plt.title('ELRS 915 MHz Waterfall — look for diagonal chirp sweeps')
            plt.tight_layout()
            plt.show()
        except ImportError:
            print("[WARN] matplotlib not available for waterfall plot")

    # ── Results ──────────────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print(f"  RESULT")
    print("=" * 60)
    print(f"  Detected SF       :  SF{sf}")
    print(f"  Symbol duration   :  {SF_TABLE[sf]*1e6:.0f} µs")
    print(f"  Packet rate       :  ~{PACKET_RATE[sf]} Hz")
    print(f"  Hop window budget :  {HOP_WINDOW[sf]} µs")
    print(f"  BW                :  500 kHz (fixed)")
    print(f"  SyncWord          :  0x12 (hardcoded)")
    print()
    print(f"  ► Update firmware/include/elrs_common.h:")
    print(f"    #define ELRS_SF  {sf}")
    print("=" * 60)


if __name__ == "__main__":
    main()
