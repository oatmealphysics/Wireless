# Detect that drone is being controlled and what commands are being sent

Got it. Clean scope. Here's exactly what you need to nail this.

---

## The Precise Problem

```
Detect:  Is a drone being actively controlled right now?
Decode:  What commands is the pilot sending? (throttle, pitch, roll, yaw, modes)
```

No geolocation. No fingerprinting. Just those two outputs.

---

## What You Actually Need to Intercept

ELRS packets carry two things you care about:

**RC Channels** — 16 channels, 11-bit each (0–2047)

```
CH1 = Roll        CH2 = Pitch
CH3 = Throttle    CH4 = Yaw
CH5 = Arming      CH6 = Flight Mode
CH7–16 = Aux switches
```

**Link Statistics** — transmitted every ~10 packets

```
RSSI, SNR, Link Quality, TX Power, RF Mode
```

If you're seeing RC channels updating → drone is actively being controlled. If throttle > idle threshold and arm switch is set → it's flying.

---

## Minimum Viable Hardware

| Component | Purpose | Cost |
| --- | --- | --- |
| RTL-SDR v3 | Wideband scan, find the signal | ~$25 |
| ESP32 + SX1262 breakout | Real-time packet capture | ~$15 |
| 915MHz antenna (whip or patch) | Range | ~$10 |

Start with just the RTL-SDR. You don't need the ESP32 until you've visually confirmed you can see ELRS chirps in the spectrum.

---

## Step-by-Step Build Plan

### Step 1 — See the Signal (SDR)

- Install **SDR#** or **GQRX**
- Tune to 915 MHz, set bandwidth to 1–2 MHz
- Look for the characteristic LoRa chirp — it looks like a diagonal sweep in the waterfall view
- This confirms you're in the right place before writing a single line of code

### Step 2 — Extract LoRa Parameters

ELRS publishes its parameters openly. For 915 MHz ELRS:

```
Spreading Factor:  SF6 – SF10 (depends on packet rate selected)
Bandwidth:         500 kHz
Coding Rate:       4/5
Sync Word:         0x12 (private LoRa network, not LoRaWAN)
Preamble:          2 symbols
```

At 500Hz packet rate → SF6. At 50Hz → SF10. Most drone pilots use 150–250Hz.

### Step 3 — Capture Packets (SX1262 Node)

Flash your ESP32+SX1262 with this RX-only logic:

```cpp
// Pseudocode — actual implementation uses RadioLib or LoRa.h
radio.setFrequency(915.0);
radio.setBandwidth(500.0);
radio.setSpreadingFactor(6);
radio.setCodingRate(5);
radio.setSyncWord(0x12);

while(true) {
    if (radio.receive(buffer, len) == RADIOLIB_ERR_NONE) {
        parseELRSPacket(buffer);
    }
}
```

**RadioLib** is the library you want — it supports SX1262 and has LoRa RX built in.

### Step 4 — Decode the ELRS Packet

ELRS packet structure for RC data (OTA format):

```
Byte 0:     Packet type (0x00 = RC data, 0x02 = link stats)
Bytes 1–22: 16x 11-bit channels packed (big endian bit packing)
Byte 23:    CRC8
```

Channel unpacking:

```python
def unpack_channels(data):
    channels = []
    bit_pos = 0
    for i in range(16):
        val = 0
        for b in range(11):
            byte_idx = (bit_pos + b) // 8
            bit_idx  = (bit_pos + b) % 8
            val |= ((data[byte_idx] >> bit_idx) & 1) << b
        channels.append(val)
        bit_pos += 11
    return channels  # 0–2047, center = 1024
```

Map output:

```
Throttle = channels[2]   # 0 = off, 2047 = full
Roll     = channels[0]   # 1024 = center
Pitch    = channels[1]   # 1024 = center
Yaw      = channels[3]   # 1024 = center
Armed    = channels[4]   # >1500 = armed
```

### Step 5 — Detection Logic

```python
def is_drone_active(channels):
    armed    = channels[4] > 1500
    throttle = channels[2] > 200       # above idle
    activity = any(abs(ch - 1024) > 50 # sticks moving
                   for ch in channels[:4])
    return armed and (throttle or activity)
```

If this returns True → drone is actively being controlled right now.

---

## What to Say at the Interview

The interviewer wants to know if you understand the **full signal chain**. Hit these points:

1. **LoRa is CSS modulation** — parameters must match to decode, not just frequency
2. **ELRS is open source** — packet spec is known, no reverse engineering needed
3. **Two-phase approach** — SDR to find/characterize, SX1262 node to decode in real-time
4. **Detection ≠ just presence** — you detect *active control* by checking arm switch + stick movement, not just signal existence
5. **The hard part is SF scanning** — if you don't know the packet rate the pilot selected, you need to try SF6 through SF10 sequentially until CRC passes

That last point is what separates a surface-level answer from a deep one. SF scanning with CRC validation is the actual technical crux of this problem.

---

## The One Slide Summary

```
915MHz band
    │
    ▼
SDR scan → confirm LoRa chirp present
    │
    ▼
SX1262 RX → lock SF/BW/sync word → capture raw packets
    │
    ▼
CRC validate → discard noise
    │
    ▼
Unpack 16x RC channels
    │
    ▼
Armed? + Throttle? + Stick movement?
    │
    ▼
OUTPUT: "Drone actively controlled — Throttle 67%, Banking right"
```

Want me to write the full working decoder in Python or C++ for the ESP32?