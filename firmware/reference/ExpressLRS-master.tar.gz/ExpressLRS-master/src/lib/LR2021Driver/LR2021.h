#pragma once

#include "LR2021_Regs.h"
#include "SX12xxDriverCommon.h"
#include "targets.h"

#ifdef PLATFORM_ESP8266
#include <cstdint>
#endif

#define RADIO_SNR_SCALE 4

class BufferCodec
{
public:
    virtual ~BufferCodec() {}
    virtual void encode(uint8_t *out, uint8_t *in, uint32_t len);
    virtual void decode(uint8_t *out, uint8_t *in, uint32_t len);
};

class LR2021Driver : public SX12xxDriverCommon
{
public:
    static LR2021Driver *instance;

    ////////////////Configuration Functions/////////////
    LR2021Driver();
    bool Begin(uint32_t lowBandFreq, uint32_t highBandFreq);
    void End();
    void SetTxIdleMode() { SetMode(LR2021_MODE_FS, SX12XX_Radio_All); }; // set Idle mode used when switching from RX to TX
    void Config(uint8_t bw, uint8_t sf, uint8_t cr, uint32_t freq,
                uint8_t PreambleLength, bool InvertIQ, uint8_t PayloadLength, RadioBandMod::Combined modulation,
                uint8_t fskSyncWord1, uint8_t fskSyncWord2,
                uint32_t flrcSyncWord, uint16_t flrcCrcSeed,
                SX12XX_Radio_Number_t radioNumber = SX12XX_Radio_All);
    void SetFrequencyReg(uint32_t freq, SX12XX_Radio_Number_t radioNumber, bool doRx = false, uint32_t rxTime = 0);
    void SetOutputPower(int8_t power, bool isSubGHz = true);
    void startCWTest(uint32_t freq, SX12XX_Radio_Number_t radioNumber);

    bool GetFrequencyErrorbool(SX12XX_Radio_Number_t radioNumber);
    bool FrequencyErrorAvailable() const { return false; }

    void TXnb(uint8_t *data, bool sendGeminiBuffer, uint8_t *dataGemini, SX12XX_Radio_Number_t radioNumber);
    void RXnb();

    void StartRssiInst(SX12XX_Radio_Number_t radioNumber);
    int8_t GetRssiInst(SX12XX_Radio_Number_t radioNumber);
    void GetLastPacketStats();
    void CheckForSecondPacket();

private:
    // constant used for no power change pending
    // must not be a valid power register value
    static constexpr uint8_t PWRPENDING_NONE = 0x7f;

    // LR2021_RadioOperatingModes_t currOpmode;
    RadioBandMod::Combined modulation;
    bool modeSupportsFei;
    uint8_t pwrCurrentLF;
    uint8_t pwrPendingLF;
    uint8_t pwrCurrentHF; // HF = High Frequency
    uint8_t pwrPendingHF;
    bool pwrForceUpdate;
    bool radio1isSubGHz;
    bool radio2isSubGHz;
    lr20xx_RadioOperatingModes_t fallBackMode;
    BufferCodec *codec;

    WORD_ALIGNED_ATTR uint8_t rx_buf[32] = {};
    WORD_ALIGNED_ATTR uint8_t rx2_buf[32] = {};

    bool CheckVersion(SX12XX_Radio_Number_t radioNumber);

    void SetMode(lr20xx_RadioOperatingModes_t OPmode, SX12XX_Radio_Number_t radioNumber);

    // LoRa functions
    void ConfigModParamsLoRa(uint8_t bw, uint8_t sf, uint8_t cr, SX12XX_Radio_Number_t radioNumber);
    void SetPacketParamsLoRa(uint8_t PreambleLength, uint8_t InvertIQ, SX12XX_Radio_Number_t radioNumber);
    // FSK functions
    void ConfigModParamsFSK(uint32_t Bitrate, uint8_t BWF, uint32_t Fdev, SX12XX_Radio_Number_t radioNumber);
    void SetPacketParamsFSK(uint8_t PreambleLength, SX12XX_Radio_Number_t radioNumber);
    void SetFSKSyncWord(uint8_t fskSyncWord1, uint8_t fskSyncWord2, SX12XX_Radio_Number_t radioNumber);

    // FLRC functions
    void ConfigModParamsFLRC(uint8_t bw, uint8_t cr, uint32_t bt, SX12XX_Radio_Number_t radioNumber);
    void SetPacketParamsFLRC(uint8_t PreambleLength, uint32_t syncWord, uint16_t crcSeed, SX12XX_Radio_Number_t radioNumber);

    void SetDioIrqParams(uint8_t dio);
    void SetDioAsRfSwitch();
    void CorrectRegisterForSF6(uint8_t sf, SX12XX_Radio_Number_t radioNumber);

    uint32_t GetIrqStatus(SX12XX_Radio_Number_t radioNumber);
    void ClearIrqStatus(SX12XX_Radio_Number_t radioNumber);

    static void IsrCallback_1();
    static void IsrCallback_2();
    static void IsrCallback(SX12XX_Radio_Number_t radioNumber);

    void DecodeRssiSnr(SX12XX_Radio_Number_t radioNumber);

    bool RXnbISR(SX12XX_Radio_Number_t radioNumber); // ISR for non-blocking RX routine
    void TXnbISR();                                  // ISR for non-blocking TX routine
    void CommitOutputPower();
    void WriteOutputPower(uint8_t power, SX12XX_Radio_Number_t radioNumber);
    void SetPaConfig(bool isSubGHz, SX12XX_Radio_Number_t radioNumber);

    uint16_t WriteRegMem32(uint32_t address, const uint32_t *buffer, uint8_t length, SX12XX_Radio_Number_t radioNumber);
    uint16_t LoadPatchRAM(SX12XX_Radio_Number_t radioNumber);
    uint16_t EnablePatchRAM();
};
