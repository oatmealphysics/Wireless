#include "CRSFRouter.h"

#include "OTA.h"
#include "msptypes.h"

void CRSFRouter::addConnector(CRSFConnector *connector)
{
    connectors.insert(connector);
}

void CRSFRouter::removeConnector(CRSFConnector *connector)
{
    connectors.erase(connector);
}

void CRSFRouter::addEndpoint(CRSFEndpoint *endpoint)
{
    endpoints.insert(endpoint);
}

void CRSFRouter::processMessage(CRSFConnector *connector, const crsf_header_t *message) const
{
    if (message->type == CRSF_FRAMETYPE_HEARTBEAT)
    {
        if (connector)
        {
            // The spec say's the heartbeat payload is a int16_t, so we skip the leading byte; because it's in MSB format
            connector->addDevice((crsf_addr_e)((uint8_t *)message)[sizeof(crsf_header_t) + 1]);
        }
        return;
    }

    const auto extMessage = (crsf_ext_header_t *)message;
    const crsf_frame_type_e packetType = message->type;
    if (connector && packetType >= CRSF_FRAMETYPE_DEVICE_PING)
    {
        connector->addDevice(extMessage->orig_addr);
    }

    for (const auto endpoint : endpoints)
    {
        if (endpoint->handleRaw(message))
        {
            return;
        }

        const crsf_addr_e device_id = endpoint->getDeviceId();
        if (packetType < CRSF_FRAMETYPE_DEVICE_PING || extMessage->dest_addr == device_id || extMessage->dest_addr == CRSF_ADDRESS_BROADCAST)
        {
            endpoint->handleMessage(message);
            if (packetType >= CRSF_FRAMETYPE_DEVICE_PING && extMessage->dest_addr == device_id)
            {
                return;
            }
        }
    }

    deliverMessage(connector, message);
}

void CRSFRouter::deliverMessage(const CRSFConnector *connector, const crsf_header_t *message) const
{
    const crsf_frame_type_e packetType = message->type;
    const auto extMessage = (crsf_ext_header_t *)message;

    // deliver extended header messages to the connector that 'knows' about the destination device address
    if (packetType >= CRSF_FRAMETYPE_DEVICE_PING && extMessage->dest_addr != CRSF_ADDRESS_BROADCAST)
    {
        for (const auto other : connectors)
        {
            if (other != connector && other->forwardsTo(extMessage->dest_addr))
            {
                other->forwardMessage(message);
                return;
            }
        }
    }

    // The destination is not known, or it's a broadcast message so deliver to all other connectors
    for (const auto other : connectors)
    {
        if (other != connector)
        {
            other->forwardMessage(message);
        }
    }
}

void CRSFRouter::deliverMessageTo(const crsf_addr_e destination, const crsf_header_t *message) const
{
    for (const auto other : connectors)
    {
        if (destination == CRSF_ADDRESS_BROADCAST || other->forwardsTo(destination))
        {
            other->forwardMessage(message);
            if (destination != CRSF_ADDRESS_BROADCAST) return;
        }
    }
}

void CRSFRouter::SetHeaderAndCrc(crsf_header_t *frame, const crsf_frame_type_e frameType, const uint8_t frameSize)
{
    frame->sync_byte = CRSF_SYNC_BYTE;
    frame->frame_size = frameSize;
    frame->type = frameType;

    const uint8_t crc = crsf_crc.calc((uint8_t *)&frame->type, frameSize - 1);
    frame->payload[frameSize - CRSF_FRAME_NOT_COUNTED_BYTES] = crc;
}

void CRSFRouter::SetExtendedHeaderAndCrc(crsf_ext_header_t *frame, const crsf_frame_type_e frameType, const uint8_t frameSize, const crsf_addr_e destAddr, const crsf_addr_e origAddr)
{
    frame->dest_addr = destAddr;
    frame->orig_addr = origAddr;
    SetHeaderAndCrc((crsf_header_t *)frame, frameType, frameSize);
}

void CRSFRouter::makeLinkStatisticsPacket(crsf_header_t *frame)
{
    // Note: size of crsfLinkStatistics_t used, not full elrsLinkStatistics_t
    constexpr uint8_t payloadLen = sizeof(crsfLinkStatistics_t);
    memcpy(frame->payload, &linkStats, payloadLen);
    SetHeaderAndCrc(frame, CRSF_FRAMETYPE_LINK_STATISTICS, CRSF_FRAME_SIZE(payloadLen));
}

void CRSFRouter::SetMspV2Request(uint8_t *frame, const uint16_t function, const uint8_t *payload, const uint8_t payloadLength)
{
    auto *packet = frame + sizeof(crsf_ext_header_t);
    packet[0] = 0x50;          // no error, version 2, beginning of the frame, first frame (0)
    packet[1] = 0;             // flags
    packet[2] = function & 0xFF;
    packet[3] = (function >> 8) & 0xFF;
    packet[4] = payloadLength & 0xFF;
    packet[5] = (payloadLength >> 8) & 0xFF;
    memcpy(packet + 6, payload, payloadLength);
    packet[6 + payloadLength] = CalcCRCMsp(packet + 1, payloadLength + 5); // crc = flags + function + length + payload
}

void CRSFRouter::AddMspMessage(const mspPacket_t *packet, const crsf_addr_e destination, const crsf_addr_e origin)
{
    // This allows up to 54 bytes of payload in addition to the CRSF header/CRC and MSP header/CRC
    const uint8_t totalBufferLen = CRSF_FRAME_NOT_COUNTED_BYTES + CRSF_FRAME_LENGTH_EXT_TYPE_CRC + ENCAPSULATED_MSP_HEADER_CRC_LEN + packet->payloadSize;
    if (totalBufferLen > CRSF_MAX_PACKET_LEN)
    {
        return;
    }

    // CRSF extended frame header
    uint8_t outBuffer[totalBufferLen];
    outBuffer[0] = CRSF_SYNC_BYTE;                                                                         // address
    outBuffer[1] = packet->payloadSize + ENCAPSULATED_MSP_HEADER_CRC_LEN + CRSF_FRAME_LENGTH_EXT_TYPE_CRC; // length
    outBuffer[2] = (packet->type == MSP_PACKET_RESPONSE) ? CRSF_FRAMETYPE_MSP_RESP : CRSF_FRAMETYPE_MSP_WRITE;  // packet type
    outBuffer[3] = destination;                                                                            // destination
    outBuffer[4] = origin;                                                                                 // origin

    // Encapsulated MSP payload
    outBuffer[5] = 0x30;                // header
    outBuffer[6] = packet->payloadSize; // mspPayloadSize
    outBuffer[7] = packet->function;    // packet->cmd

    // Copy packet payload into outBuffer
    for (uint16_t i = 0; i < packet->payloadSize; ++i)
    {
        outBuffer[8 + i] = packet->payload[i];
    }

    // Encapsulated MSP crc
    outBuffer[totalBufferLen - 2] = CalcCRCMsp(&outBuffer[6], packet->payloadSize + 2);

    // CRSF frame crc
    outBuffer[totalBufferLen - 1] = crsf_crc.calc(&outBuffer[2], packet->payloadSize + ENCAPSULATED_MSP_HEADER_CRC_LEN + CRSF_FRAME_LENGTH_EXT_TYPE_CRC - 1);
    deliverMessageTo(destination, (crsf_header_t *)outBuffer);
}

uint8_t CRSFRouter::getConnectorMaxPacketSize(const crsf_addr_e origin) const
{
    for (const auto connector : connectors)
    {
        if (connector->forwardsTo(origin))
        {
            return connector->GetMaxPacketBytes();
        }
    }
    return CRSF_MAX_PACKET_LEN;
}
