"""
UHD device wrapper — symmetric RX/TX for B210 / B205mini.

One class serves both directions so the TX path (future) reuses the exact same
device handling as RX. UHD's Python API is direction-symmetric
(set_tx_freq/set_tx_rate mirror set_center_freq/set_sample_rate), so nothing
here is hardcoded to receive.

Usage (RX):
    radio = RadioDevice("type=b200")        # auto-detect B205/B210
    radio.tune(2.44e9, sample_rate=4e6, gain=40)
    for chunk in radio.rx_stream(1024):
        process(chunk)                      # np.complex64

Usage (TX, future):
    radio.tx_tune(2.44e9, sample_rate=4e6, gain=10)
    radio.tx_stream(waveform)               # np.complex64

IQ capture to file uses the standard .complex8 (int16 I,Q interleaved) SDR
format so files open in GQRtx / SDR# / our own decoder.
"""

from __future__ import annotations

import time
import numpy as np

try:
    import uhd
    _HAVE_UHD = True
except ImportError:
    _HAVE_UHD = False


class UHDNotInstalled(RuntimeError):
    pass


class RadioDevice:
    """Direction-agnostic UHD USRP wrapper."""

    def __init__(self, args: str = "type=b200", rx_channel: int = 0,
                 tx_channel: int = 0):
        if not _HAVE_UHD:
            raise UHDNotInstalled(
                "The 'uhd' python module is not importable. Install UHD with "
                "python bindings on the machine where the radio is attached."
            )
        self.args = args
        self.rx_channel = rx_channel
        self.tx_channel = tx_channel
        self._usrp = uhd.usrp_multi_usrp(args)
        self._sample_rate = None
        self._freq = None
        self._gain = None

    # ------------------------------------------------------------------ #
    # device info
    # ------------------------------------------------------------------ #
    @property
    def device(self):
        return self._usrp

    def get_gain_range(self, chan: int | None = None) -> list:
        c = chan if chan is not None else self.rx_channel
        return self._usrp.get_rx_gain_range(c)

    def get_antennas(self, direction: str = "rx", chan: int | None = None) -> list:
        c = chan if chan is not None else (self.rx_channel if direction == "rx"
                                           else self.tx_channel)
        if direction == "rx":
            return list(self._usrp.get_rx_antennas(c))
        return list(self._usrp.get_tx_antennas(c))

    # ------------------------------------------------------------------ #
    # RX setup
    # ------------------------------------------------------------------ #
    def tune(self, freq_hz: float, sample_rate: float, gain: float,
             antenna: str | None = None):
        """Configure the RX chain. freq_hz is the RF center."""
        self._usrp.set_center_freq(uhd.tune_request(freq_hz), self.rx_channel)
        self._usrp.set_sample_rate(sample_rate, self.rx_channel)
        self._usrp.set_rx_gain(gain, self.rx_channel)
        if antenna:
            self._usrp.set_antenna(antenna, self.rx_channel)
        self._freq, self._sample_rate, self._gain = freq_hz, sample_rate, gain

    def rx_stream_args(self, ctype: str = "fc32") -> uhd.stream_args:
        return uhd.stream_args(ctype, "")

    def get_rx_stream(self) -> "uhd.rx_stream":
        return self._usrp.get_rx_stream()

    def rx_stream(self, chunk: int = 1024, timeout_s: float = 0.25,
                  ctype: str = "fc32"):
        """
        Generator yielding np.complex64 chunks of up to `chunk` samples.
        Runs until the generator is closed / GC'd. Use for live monitoring.
        """
        args = self.rx_stream_args(ctype)
        stream = self._usrp.get_rx_stream()
        buf = np.zeros(chunk, dtype=np.complex64)
        meta = uhd.rx_metadata()
        while True:
            count = stream.recv(buf, chunk, uhd.timeout(timeout_s), meta)
            if count > 0:
                yield buf[:count].copy()

    def capture(self, n_samples: int, path: str | None = None,
                ctype: str = "fc32", log_every: int = 1 << 20):
        """
        Capture a fixed number of IQ samples. Returns an np.complex64 array.
        If `path` is given, also writes a .complex8 file (SDR#, GQRtx format).
        """
        args = self.rx_stream_args(ctype)
        stream = self._usrp.get_rx_stream()
        out = np.empty(n_samples, dtype=np.complex64)
        got = 0
        buf = np.zeros(min(4096, n_samples), dtype=np.complex64)
        meta = uhd.rx_metadata()
        t0 = time.time()
        while got < n_samples:
            n = stream.recv(buf, len(buf), uhd.timeout(0.5), meta)
            if n == 0:
                continue
            space = n_samples - got
            take = min(n, space)
            out[got:got + take] = buf[:take]
            got += take
            if (got // log_every) != ((got - take) // log_every):
                rate = got / max(time.time() - t0, 1e-9)
                print(f"  captured {got}/{n_samples} @ {rate/1e6:.2f} MS/s",
                      flush=True)
        if path:
            _write_complex8(out, path)
            print(f"  wrote {path}", flush=True)
        return out

    # ------------------------------------------------------------------ #
    # TX setup (future) — mirrors the RX API
    # ------------------------------------------------------------------ #
    def tx_tune(self, freq_hz: float, sample_rate: float, gain: float,
                antenna: str | None = None):
        """Configure the TX chain."""
        self._usrp.set_tx_freq(uhd.tune_request(freq_hz), self.tx_channel)
        self._usrp.set_tx_rate(sample_rate, self.tx_channel)
        self._usrp.set_tx_gain(gain, self.tx_channel)
        if antenna:
            self._usrp.set_tx_antenna(antenna, self.tx_channel)
        self._freq, self._sample_rate, self._gain = freq_hz, sample_rate, gain

    def tx_stream(self, samples: np.ndarray, chunk: int = 4096):
        """
        Transmit a complex64 waveform. Splits into chunks and sends via
        UHD's TX stream. Requires the device to support TX and a TX antenna.
        """
        args = uhd.stream_args("fc32", "")
        stream = self._usrp.get_tx_stream()
        sent = 0
        n = len(samples)
        while sent < n:
            take = min(chunk, n - sent)
            meta = uhd.tx_metadata()
            if sent + take == n:
                meta.set_end_of_burst(True)
            c = 0
            while c < take:
                r = stream.send(samples[sent + c:sent + c + chunk],
                                uhd.timeout(1.0), meta)
                c += r
            sent += c
        # wait for the burst to fully leave the device
        meta = uhd.tx_metadata()
        while not meta.has_tx_done():
            stream.wait_for_tx_complete(uhd.timeout(1.0), meta)


# ----------------------------------------------------------------------------
# .complex8 file I/O (SDR standard: int16 I,Q interleaved)
# ----------------------------------------------------------------------------
def _write_complex8(samples: np.complex64, path: str):
    i = np.clip(samples.real, -1, 1)
    q = np.clip(samples.imag, -1, 1)
    inter = np.empty(len(samples) * 2, dtype=np.int16)
    inter[0::2] = (i * 32767).astype(np.int16)
    inter[1::2] = (q * 32767).astype(np.int16)
    inter.tofile(path)


def read_complex8(path: str) -> np.complex64:
    raw = np.fromfile(path, dtype=np.int16)
    raw = raw[: (len(raw) // 2) * 2]
    i = raw[0::2].astype(np.float32) / 32767.0
    q = raw[1::2].astype(np.float32) / 32767.0
    return (i + 1j * q).astype(np.complex64)
