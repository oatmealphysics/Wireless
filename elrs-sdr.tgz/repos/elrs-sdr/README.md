# elrs-sdr

Capture, decode — and (future) transmit — ExpressLRS drone signals with an
Ettus B210 / B205mini.

Built from a first-hand read of the [ExpressLRS](https://github.com/ExpressLRS/ExpressLRS)
source (`main`), so the protocol layers are exact ports, not guesses.

## What this is / isn't

| Layer | Status | Why |
|---|---|---|
| CRC (Crc2Byte 14/16-bit, CRC8 0xD5) | ✅ exact port, self-tested | byte-for-byte from `src/lib/CRC` |
| OTA packet model (8-byte std / 13-byte full) | ✅ exact port, self-tested | from `src/lib/OTA` |
| UID-derived CRC init + binding-mode init | ✅ exact port, self-tested | `OtaUpdateCrcInitFromUid` / `EnterBindingMode` |
| Channel pack/unpack (4×10-bit in 5 bytes) | ✅ exact port, self-tested | `Pack/UnpackUInt11ToChannels4x10` |
| FHSS LCG + regulatory domains + hop sequence | ✅ exact port, self-tested | `src/lib/FHSS` |
| LoRa PHY (SF5-8 @ 800 kHz, chirp mod/demod) | ⚠️ first-order | Semtech-proprietary bit mapping; **needs a real capture to validate** |
| UHD transport (RX now, TX built but gated) | ✅ API-complete | direction-symmetric by design |

The LoRa demod is the single layer that can't be proven on a desk: the
SF5/SF6 bit-per-symbol convention, BPSK differencing, and interleaving are
Semtech implementation details. The code is structured so that the **first real
capture** becomes a unit test for `lora.py` — everything above it is already
validated against the exact CRC.

## The decoding barrier (read this first)

ELRS validates each frame with a CRC whose **init is derived from the link's
6-byte UID**:

```
OtaCrcInitializer = (UID[4]<<8 | UID[5]) ^ (OTA_VERSION_ID << 8)   # OTA_VERSION_ID = 4
```

Without the UID you can demodulate the LoRa frame but you **cannot** validate
its CRC, so you can't tell real packets from noise. Two on-ramps:

1. **Bind-mode capture (easiest).** Put the TX in bind mode. In bind mode the
   CRC init collapses to `OTA_VERSION_ID` (no UID) and the nonce is forced 0,
   so frames validate *without knowing the UID*. The sync packet then carries
   `UID4`/`UID5` directly. This is what `bind-capture` does.
2. **Known UID.** If you already have the link UID (e.g. from a bound RX),
   pass `--uid <hex>` and frames validate normally.

`OtaGetUidSeed` (the FHSS-seed derivation) also depends on the UID, so
reconstructing the *hop sequence* for a moving link needs the full UID — bind
mode gives you the two low bytes; the other four arrive over MSP during a real
bind.

## Install (on the machine with the radio)

```bash
# UHD with python bindings (Debian/Ubuntu)
sudo apt install uhd-host
# ensure `import uhd` works in your python:
python3 -c "import uhd; print(uhd.version())"

# project deps
cd elrs-sdr
python3 -m venv .venv
.venv/bin/pip install numpy
.venv/bin/pip install -e .        # optional: installs the `elrs-sdr` command
```

Verify the stack without hardware:

```bash
.venv/bin/python -m elrs_sdr.selftest    # all 27 checks should pass
.venv/bin/python -m elrs_sdr --help
```

## Usage

Run from the repo dir as `python -m elrs_sdr …` or, if you ran `pip install -e .`,
just `elrs-sdr …`.

```bash
# 1. Confirm the radio is visible
python -m elrs_sdr info

# 2. Find where the drone's hops are (2.4 GHz sweep)
python -m elrs_sdr scan --sweep 80 --dwell-ms 25

# 3. Capture IQ at a frequency of interest (opens in GQRtx / SDR# too)
python -m elrs_sdr capture --freq 2440e6 --srate 4e6 --gain 40 \
       --samples 4194304 --out cap.complex8

# 4. Decode a capture offline (binding-mode init by default)
python -m elrs_sdr decode cap.complex8 --rate 250Hz

#    …or with a known UID:
python -m elrs_sdr decode cap.complex8 --rate 250Hz --uid aabbccddeeff

# 5. Live decode loop
python -m elrs_sdr monitor --freq 2440e6 --rate 250Hz

# 6. Bind-mode capture to recover the link UID
python -m elrs_sdr bind-capture --samples 4194304 --out bind.complex8
python -m elrs_sdr decode bind.complex8 --rate 50Hz

# 7. TX — GATED, future
python -m elrs_sdr tx --rate 250Hz                 # refuses without the flag
python -m elrs_sdr tx --rate 250Hz \
       --i-am-authorized-to-transmit               # only if you own the link
```

### Air rates (2.4 GHz, SX1280)

| `--rate` | SF | BW | CR | OTA | interval |
|---|---|---|---|---|---|
| `500Hz` | 5 | 800k | 4/6 | 8-byte | 2 ms |
| `333Hz_8ch` | 5 | 800k | 4/8 | **13-byte** | 3 ms |
| `250Hz` | 6 | 800k | 4/8 | 8-byte | 4 ms |
| `150Hz` | 7 | 800k | 4/8 | 8-byte | 6.7 ms |
| `100Hz_8ch` | 7 | 800k | 4/8 | **13-byte** | 10 ms |
| `50Hz` | 8 | 800k | 4/8 | 8-byte | 20 ms |

800 kHz LoRa needs ≥ ~4 MS/s to be captured comfortably — the default `--srate 4e6`
is set for that. (The 1000Hz/500Hz 2.4 GHz rates are **FLRC**, not LoRa, and are
out of scope for the LoRa path.)

## Architecture (RX/TX symmetric by design)

```
cli.py        subcommands: info/scan/capture/decode/monitor/bind-capture/tx
  │
radio.py      RadioDevice — ONE UHD wrapper, symmetric RX+TX
  │           rx_stream()/capture()  ↔  tx_stream()/tx_tune()
  │           .complex8 file I/O (SDR# / GQRtx compatible)
  │
lora.py       LoRa PHY — chirp mod/demod, IQ inversion, preamble+sync detect
  │           modulate_frame()  ↔  demodulate_frame()   [needs capture validation]
  │
ota.py        OTA packet model — build_*/decode_*/validate_*/generate_*
  │           the SAME functions serve RX (validate+unpack) and TX (build+pack)
  │
crc.py        Crc2Byte + Crc8 — exact ports
fhss.py       LCG + domains + hop-sequence builder
```

Adding TX later is *wiring, not re-implementation*: `ota.build_*` and
`lora.modulate_frame` already produce the frames and waveforms; `radio.tx_stream`
already sends them. The only gates are the authorization flag and validating the
TX-side LoRa bit mapping against the same real capture used to validate RX.

## Legal / safety

This tool can demodulate and (eventually) transmit on the 2.4 GHz ISM band that
FPV drones use. **Capture is passive.** Transmission is disabled by default and
requires an explicit `--i-am-authorized-to-transmit` flag. Only transmit on
links you own, in an isolated/regulated environment, and within your local
regulatory limits.
