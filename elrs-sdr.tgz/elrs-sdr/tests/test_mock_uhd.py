"""
Mock-UHD harness: proves the binding-tolerant radio.py works end-to-end WITHOUT
a real radio. Simulates the UHD 4.11 (apt) pybind API surface — the binding the
operator laptop actually has — and drives RadioDevice through the full RX setup
+ a recv. If this passes, the code path that previously failed (recv=0 because
the RX chain was never activated) is wired correctly.
"""
import sys, types, numpy as np

# ---- build a fake `uhd` module matching the 4.11 API ----------------------
uhd = types.ModuleType("uhd")

class _SampleRange:
    def get_min_rate(self): return 1e6
    def get_max_rate(self): return 61.44e6
    def get_step_rate(self): return 1e3

class _RXStream:
    def __init__(self, n=4096): self._n = n; self._calls = 0
    def recv(self, *a):
        # polymorphic: accept (buf, meta, timeout) [4.9/4.11] or (buf, timeout, meta)
        buf = a[0] if isinstance(a[0], np.ndarray) else a[0]
        self._calls += 1
        if getattr(self, "_ready", False):
            n = min(self._n, len(buf))
            buf[:n] = np.exp(2j*np.pi*np.linspace(0,3,n)).astype(np.complex64)
            return n
        return 0  # timeout, all-zero — the bug symptom

class _Device:
    _ANTENNAS = {"TX/RX"}  # B205mini is single-chain; RX2 is NOT a real antenna
    def __init__(self, args):
        self.args = args
        self._subdev = None; self._antenna = None; self._dc = None
        self._freq = self._rate = self._gain = None
        self._stream = _RXStream()
        self._stream._ready = False
    def set_subdev_spec(self, spec, ch): self._subdev = (spec, ch)
    def set_antenna(self, name, ch):
        # like the real board: an invalid antenna name raises
        if name not in self._ANTENNAS:
            raise RuntimeError(f"Antenna {name!r} not found (valid: {sorted(self._ANTENNAS)})")
        self._antenna = (name, ch)
    def set_dc_offset_mode(self, on, ch): self._dc = (on, ch)
    def get_antenna_names(self, ch): return list(self._ANTENNAS)
    def get_firmware_revision(self): return "4.11.0.0-mock"
    def set_rx_freq(self, f): self._freq = f
    def set_rx_rate(self, r): self._rate = r
    def set_rx_gain(self, g): self._gain = g
    def set_center_freq(self, tr, ch):
        raise AttributeError("set_center_freq does not exist on 4.11 (correct)")
    def get_rx_stream(self, sa=None):
        # mark the stream ready only if the chain was activated first
        self._stream._ready = (self._subdev is not None and self._antenna is not None)
        return self._stream
    def get_rx_sample_rates(self, ch): return _SampleRange()

class _MultiUSRP:
    def __init__(self, args): self._d = _Device(args)
    def __getattr__(self, name): return getattr(self._d, name)

# wire the 4.11 surface: uhd.usrp is a MODULE with MultiUSRP
usrp_mod = types.ModuleType("uhd.usrp")
usrp_mod.MultiUSRP = _MultiUSRP
uhd.usrp = usrp_mod

types_mod = types.ModuleType("uhd.types")
class RXMetadata: pass
types_mod.RXMetadata = RXMetadata
uhd.types = types_mod
uhd.stream_args = lambda fmt="", meta="": (fmt, meta)
uhd.timeout = lambda s: ("timeout", s)
# NOTE: 4.11 does NOT have uhd.usrp_multi_usrp -> _open_usrp must find MultiUSRP

sys.modules["uhd"] = uhd
sys.modules["uhd.usrp"] = usrp_mod
sys.modules["uhd.types"] = types_mod

# ---- now drive the real code through the fake ----------------------------
import os
# Make the project root (parent of this tests/ dir) importable so it runs
# from anywhere in the tarball:  python tests/test_mock_uhd.py
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
sys.path.insert(0, ROOT)

from elrs_sdr.radio import RadioDevice, UHDNotInstalled

print("== 1. constructor resolution (must find uhd.usrp.MultiUSRP) ==")
r = RadioDevice("type=b200")
print("   opened OK, device:", type(r.device).__name__)

print("== 2. tune() must use set_rx_* (NOT set_center_freq) ==")
r.tune(2.44e9, 4e6, 40, None)
print("   freq/rate/gain:", r.device._freq, r.device._rate, r.device._gain)
assert r.device._freq == 2.44e9, "tune did not set freq"

print("== 3. set_freq() (scan path) must use set_rx_freq ==")
r.set_freq(2.45e9)
assert r.device._freq == 2.45e9
print("   set_freq OK:", r.device._freq)

print("== 4. RX chain activation (the subdev/antenna gate) ==")
stream = r._open_rx_stream()
print("   subdev:", r.device._subdev, "antenna:", r.device._antenna, "dc:", r.device._dc)
assert r.device._subdev is not None, "set_subdev_spec was never called (BUG)"
assert r.device._antenna is not None, "set_antenna was never called (BUG)"
assert r.device._antenna[0] == "TX/RX", \
    f"antenna is {r.device._antenna[0]!r}, expected 'TX/RX' (B205mini single-chain RF path)"
print("   antenna correctly resolved to TX/RX (B205mini RF path)")

print("== 5. recv must now DELIVER samples (was 0 before the fix) ==")
buf = np.zeros(8192, dtype=np.complex64)
n = r._recv(stream, buf, 0.2)
print("   recv returned", n, "samples; absmax =", float(np.abs(buf[:n]).max()))
assert n > 0, "recv returned 0 — RX chain still not activated (BUG)"
assert np.abs(buf[:n]).max() > 0, "buffer all-zero after recv (BUG)"

print("== 6. info-path: get_rx_sample_rates works on 4.11 ==")
sr = r.device.get_rx_sample_rates(0)
print("   sample range:", sr.get_min_rate()/1e6, "-", sr.get_max_rate()/1e6, "Msps")

print("\nALL MOCK-UHD 4.11 CHECKS PASSED")
