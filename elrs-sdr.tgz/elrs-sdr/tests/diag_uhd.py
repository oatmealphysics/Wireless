#!/usr/bin/env python3
"""
One-shot UHD 4.11 diagnostic — run this AFTER `git pull` + re-extract.
It opens the real board and prints the EXACT API surface for the two things
that have been failing (meta_range_t accessors, StreamArgs), so the fix can be
confirmed against reality instead of guesswork. Safe: read-only, no TX.

    python3 diag_uhd.py
"""
import sys, traceback
try:
    import uhd
except Exception as e:
    print("import uhd failed:", e); sys.exit(1)

print("== UHD module ==")
print("  version :", uhd.get_version_string() if hasattr(uhd, "get_version_string") else "?")
print("  dir(uhd) has StreamArgs? ", hasattr(uhd, "stream_args"),
      "| uhd.usrp.StreamArgs?", hasattr(getattr(uhd, "usrp", None), "StreamArgs"))

# open the board
try:
    d = uhd.usrp.MultiUSRP("type=b200")
except Exception:
    try:
        d = uhd.usrp.multi_usrp("type=b200")
    except Exception as e:
        print("could not open board:", e); sys.exit(1)
print("  opened board OK")

print("\n== meta_range_t accessors (get_rx_rates) ==")
try:
    r = d.get_rx_rates(0)
except Exception as e:
    print("  get_rx_rates(0) failed:", e)
else:
    print("  type:", type(r).__name__)
    nums = {}
    for attr in sorted(dir(r)):
        if attr.startswith("get_"):
            c = getattr(r, attr, None)
            if callable(c):
                try:
                    v = c()
                except Exception as ee:
                    print(f"  {attr}() raised: {ee}")
                    continue
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    nums[attr] = v
    for k, v in nums.items():
        print(f"  {k}() = {v}")
    if not nums:
        print("  (no numeric get_* found — that's why info said 'unrecognized')")

print("\n== StreamArgs factory (get_rx_stream requires it) ==")
for name in ("stream_args", "StreamArgs", "StreamArgs_t"):
    for holder in (uhd, getattr(uhd, "usrp", None)):
        f = getattr(holder, name, None)
        if callable(f):
            print(f"  found {holder.__name__ if hasattr(holder,'__name__') else 'uhd'}.{name}")
            for args in (("fc32", ""), ("fc32",)):
                try:
                    sa = f(*args)
                    print(f"    {name}{args} -> {type(sa).__name__}")
                    break
                except Exception as e:
                    print(f"    {name}{args} failed: {e}")
            break

print("\n== try opening the RX stream with StreamArgs ==")
try:
    sa = uhd.usrp.StreamArgs("fc32", "")
    st = d.get_rx_stream(sa)
    print("  get_rx_stream(StreamArgs) OK ->", type(st).__name__)
    import numpy as np
    meta = uhd.types.RXMetadata()
    buf = np.zeros(1024, dtype=np.complex64)
    n = st.recv(buf, meta, 0.2)
    print(f"  recv returned {n} samples (absmax={float(np.abs(buf[:max(n,1)]).max()) if n else 0})")
    if n == 0:
        print("  NOTE: 0 samples — chain may need set_subdev_spec/set_antenna "
              "(our wrapper does this; this raw test may not have)")
except Exception as e:
    print("  failed:", repr(e))

print("\nDONE")
