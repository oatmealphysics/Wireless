#!/usr/bin/env python3
"""
One-shot UHD 4.11 diagnostic — run this AFTER `git pull` + re-extract.
It opens the real board and prints the EXACT API surface for the two things
that have been failing (meta_range_t accessors, StreamArgs), so the fix can be
confirmed against reality instead of guesswork. Safe: read-only, no TX.

    python3 diag_uhd.py
"""
import sys, traceback
try:
    import uhd
except Exception as e:
    print("import uhd failed:", e); sys.exit(1)

print("== UHD module ==")
print("  version :", uhd.get_version_string() if hasattr(uhd, "get_version_string") else "?")
print("  dir(uhd) has StreamArgs? ", hasattr(uhd, "stream_args"),
      "| uhd.usrp.StreamArgs?", hasattr(getattr(uhd, "usrp", None), "StreamArgs"))

# open the board
try:
    d = uhd.usrp.MultiUSRP("type=b200")
except Exception:
    try:
        d = uhd.usrp.multi_usrp("type=b200")
    except Exception as e:
        print("could not open board:", e); sys.exit(1)
print("  opened board OK")

print("\n== meta_range_t accessors (get_rx_rates) ==")
try:
    r = d.get_rx_rates(0)
except Exception as e:
    print("  get_rx_rates(0) failed:", e)
else:
    print("  type:", type(r).__name__)
    # EXHAUSTIVE: dump every attribute, and call any callable that takes no args
    print("  --- dir() (non-dunder) ---")
    for attr in sorted(dir(r)):
        if attr.startswith("__") and attr.endswith("__"):
            continue
        print("   ", attr)
    print("  --- calling no-arg methods ---")
    for attr in sorted(dir(r)):
        if attr.startswith("__"):
            continue
        c = getattr(r, attr, None)
        if callable(c):
            try:
                v = c()
                print(f"   {attr}() = {v!r}  ({type(v).__name__})")
            except Exception as ee:
                print(f"   {attr}() -> raised {type(ee).__name__}: {ee}")
    # is it iterable / indexable / has len?
    for probe in ("len", "iter", "getitem"):
        try:
            if probe == "len":
                print("   len(r) =", len(r))
            elif probe == "iter":
                it = iter(r); print("   iter works; first few:", [next(it) for _ in range(3)])
            elif probe == "getitem":
                print("   r[0] =", r[0])
        except Exception as ee:
            print(f"   {probe}: {type(ee).__name__}: {ee}")

print("\n== StreamArgs factory (get_rx_stream requires it) ==")
for name in ("stream_args", "StreamArgs", "StreamArgs_t"):
    for holder in (uhd, getattr(uhd, "usrp", None)):
        f = getattr(holder, name, None)
        if callable(f):
            print(f"  found {holder.__name__ if hasattr(holder,'__name__') else 'uhd'}.{name}")
            for args in (("fc32", ""), ("fc32",)):
                try:
                    sa = f(*args)
                    print(f"    {name}{args} -> {type(sa).__name__}")
                    break
                except Exception as e:
                    print(f"    {name}{args} failed: {e}")
            break

print("\n== RX stream: WITH and WITHOUT chain activation ==")
import numpy as np
def _recv_test(st, label, seconds=0.3):
    meta = uhd.types.RXMetadata()
    buf = np.zeros(2048, dtype=np.complex64)
    total = 0
    import time
    t0 = time.time()
    peak = 0.0
    while time.time() - t0 < seconds:
        n = st.recv(buf, meta, 0.1)
        if n:
            total += n
            peak = max(peak, float(np.abs(buf[:n]).max()))
    print(f"  {label}: {total} samples over {seconds:.1f}s (peak abs={peak:.4f})")
    return total

try:
    sa = uhd.usrp.StreamArgs("fc32", "")
    # A) NO chain activation (raw) — baseline
    st = d.get_rx_stream(sa)
    print("  (A) no set_subdev_spec/set_antenna:")
    a = _recv_test(st, "A raw")
    st.stop_stream() if hasattr(st, "stop_stream") else None
    # B) WITH chain activation (what our radio.py _ensure_rx_chain does)
    try:
        d.set_subdev_spec("A", 0)
    except Exception as e:
        print("    set_subdev_spec('A',0) failed:", e)
    for ant in ("TX/RX", "RX2"):
        try:
            d.set_antenna(ant, 0); print(f"    set_antenna({ant!r}) ok"); break
        except Exception as e:
            print(f"    set_antenna({ant!r}) failed: {e}")
    try:
        d.set_dc_offset_mode(True, 0); print("    set_dc_offset_mode(True) ok")
    except Exception as e:
        print("    set_dc_offset_mode failed:", e)
    st2 = d.get_rx_stream(sa)
    print("  (B) after set_subdev_spec/set_antenna:")
    b = _recv_test(st2, "B chain-on")
    print(f"  => chain activation {'CHANGES the result' if a != b else 'makes no difference'} "
          f"(A={a}, B={b})")
except Exception as e:
    print("  failed:", repr(e))

print("\nDONE")
