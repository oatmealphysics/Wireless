#!/usr/bin/env python3
"""
One-shot UHD 4.11 diagnostic — run this AFTER `git pull` + re-extract.
It opens the real board and prints the EXACT API surface for the two things
that have been failing (meta_range_t accessors, StreamArgs), so the fix can be
confirmed against reality instead of guesswork. Safe: read-only, no TX.

    python3 diag_uhd.py
"""
import sys, traceback
try:
    import uhd
except Exception as e:
    print("import uhd failed:", e); sys.exit(1)

print("== UHD module ==")
print("  version :", uhd.get_version_string() if hasattr(uhd, "get_version_string") else "?")
print("  dir(uhd) has StreamArgs? ", hasattr(uhd, "stream_args"),
      "| uhd.usrp.StreamArgs?", hasattr(getattr(uhd, "usrp", None), "StreamArgs"))

# open the board
try:
    d = uhd.usrp.MultiUSRP("type=b200")
except Exception:
    try:
        d = uhd.usrp.multi_usrp("type=b200")
    except Exception as e:
        print("could not open board:", e); sys.exit(1)
print("  opened board OK")

print("\n== meta_range_t accessors (get_rx_rates) ==")
try:
    r = d.get_rx_rates(0)
except Exception as e:
    print("  get_rx_rates(0) failed:", e)
else:
    print("  type:", type(r).__name__)
    # EXHAUSTIVE: dump every attribute, and call any callable that takes no args
    print("  --- dir() (non-dunder) ---")
    for attr in sorted(dir(r)):
        if attr.startswith("__") and attr.endswith("__"):
            continue
        print("   ", attr)
    print("  --- calling no-arg methods ---")
    for attr in sorted(dir(r)):
        if attr.startswith("__"):
            continue
        c = getattr(r, attr, None)
        if callable(c):
            try:
                v = c()
                print(f"   {attr}() = {v!r}  ({type(v).__name__})")
            except Exception as ee:
                print(f"   {attr}() -> raised {type(ee).__name__}: {ee}")
    # is it iterable / indexable / has len?
    for probe in ("len", "iter", "getitem"):
        try:
            if probe == "len":
                print("   len(r) =", len(r))
            elif probe == "iter":
                it = iter(r); print("   iter works; first few:", [next(it) for _ in range(3)])
            elif probe == "getitem":
                print("   r[0] =", r[0])
        except Exception as ee:
            print(f"   {probe}: {type(ee).__name__}: {ee}")

print("\n== StreamArgs factory (get_rx_stream requires it) ==")
for name in ("stream_args", "StreamArgs", "StreamArgs_t"):
    for holder in (uhd, getattr(uhd, "usrp", None)):
        f = getattr(holder, name, None)
        if callable(f):
            print(f"  found {holder.__name__ if hasattr(holder,'__name__') else 'uhd'}.{name}")
            for args in (("fc32", ""), ("fc32",)):
                try:
                    sa = f(*args)
                    print(f"    {name}{args} -> {type(sa).__name__}")
                    break
                except Exception as e:
                    print(f"    {name}{args} failed: {e}")
            break

print("\n== RX stream: WITH and WITHOUT chain activation ==")
import numpy as np

def _make_stream_cmd(mode_name):
    """Construct a stream_cmd across 4.11 API spellings, or None.

    UHD stream_cmd_t holds a stream_mode_t. The 4.11 pybind exposes these as
    uhd.types.stream_cmd / StreamCmd and uhd.types.stream_mode / StreamMode,
    with START/STOP/NO_OVERFLOW/... as attributes. Try the plausible shapes
    and print what we find so the exact API is confirmed.
    """
    types = getattr(uhd, "types", None)
    # find the cmd class and the mode enum/class
    cmd_cls = None
    for holder in (uhd, types, getattr(uhd, "usrp", None)):
        if holder is None: continue
        for n in ("stream_cmd", "StreamCmd", "stream_cmd_t"):
            c = getattr(holder, n, None)
            if callable(c):
                cmd_cls = c; break
        if cmd_cls: break
    mode_cls = None
    for holder in (uhd, types, getattr(uhd, "usrp", None)):
        if holder is None: continue
        for n in ("stream_mode", "StreamMode", "stream_mode_t"):
            c = getattr(holder, n, None)
            if c is not None:
                mode_cls = c; break
        if mode_cls: break
    if cmd_cls is None:
        print("   (no stream_cmd class found under uhd/uhd.types/uhd.usrp)")
        # dump what IS in uhd.types so we see the real names
        if types is not None:
            print("   uhd.types has:", [a for a in dir(types) if not a.startswith("__")])
        return None
    print(f"   stream_cmd class = {cmd_cls}, stream_mode = {mode_cls}")
    # try to get the START mode
    start_mode = None
    if mode_cls is not None:
        for n in ("START", "start", "START_STREAM"):
            m = getattr(mode_cls, n, None)
            if m is not None:
                start_mode = m; break
        if start_mode is None:
            # maybe it's an instance method: mode_cls().set_stream_mode(START)
            try:
                inst = mode_cls()
                for n in ("START", "start"):
                    if hasattr(inst, n):
                        start_mode = getattr(inst, n); break
            except Exception:
                pass
    # try constructor shapes
    for shape in (
        lambda: cmd_cls(start_mode) if start_mode is not None else None,
        lambda: cmd_cls(),
        lambda: cmd_cls(start_mode, 0, False) if start_mode is not None else None,
    ):
        try:
            cmd = shape()
            if cmd is not None:
                print(f"   built {type(cmd).__name__}")
                return cmd
        except Exception as e:
            print(f"   ctor shape failed: {e}")
    return None

# DUMP every set_rx_*/get_rx_* method on the device so we see the EXACT 4.11
# names for antenna / subdev / dc-offset / rate / gain / freq — no more guessing.
print("  --- device RX methods (set_rx_* / get_rx_*) ---")
for attr in sorted(dir(d)):
    if attr.startswith("set_rx_") or attr.startswith("get_rx_") or attr in ("set_antenna","get_antenna_names","set_subdev_spec","set_dc_offset_mode"):
        print("   ", attr)
def _recv_test(st, label, seconds=0.3):
    meta = uhd.types.RXMetadata()
    buf = np.zeros(2048, dtype=np.complex64)
    total = 0
    import time
    t0 = time.time()
    peak = 0.0
    while time.time() - t0 < seconds:
        n = st.recv(buf, meta, 0.1)
        if n:
            total += n
            peak = max(peak, float(np.abs(buf[:n]).max()))
    print(f"  {label}: {total} samples over {seconds:.1f}s (peak abs={peak:.4f})")
    return total

try:
    sa = uhd.usrp.StreamArgs("fc32", "")
    # Set the RF up the way the WORKING methods do (set_rx_* family).
    try:
        d.set_rx_rate(4e6); print("  set_rx_rate(4e6) ok")
    except Exception as e: print("  set_rx_rate failed:", e)
    try:
        d.set_rx_freq(2.44e9); print("  set_rx_freq(2.44e9) ok")
    except Exception as e: print("  set_rx_freq failed:", e)
    try:
        d.set_rx_gain(30); print("  set_rx_gain(30) ok")
    except Exception as e: print("  set_rx_gain failed:", e)
    # Antenna via the set_rx_* family (the non-rx set_antenna does NOT exist on 4.11)
    ant_ok = False
    for m in ("set_rx_antenna", "set_antenna", "set_rx_subdev_spec"):
        if hasattr(d, m):
            for arg in (("TX/RX", 0), ("RX2", 0), ("TX/RX",), (0,)):
                try:
                    getattr(d, m)(*arg); print(f"  {m}{arg} ok"); ant_ok=True; break
                except Exception:
                    continue
            if ant_ok: break
    print("  (antenna set ok)" if ant_ok else "  (no antenna method worked — see dump above)")
    st = d.get_rx_stream(sa)
    print("  (after set_rx_rate/freq/gain/antenna):")
    b = _recv_test(st, "B rx-configured")
    if b == 0:
        print("  === still 0 samples — probing likely causes ===")
        # 1) Does the streamer need issue_stream_cmd(stream_cmd_t(START))?
        #    The 4.11 binding needs a uhd.types.stream_cmd object with a StreamMode.
        print("  -- trying issue_stream_cmd with a constructed stream_cmd --")
        started = False
        for cmd_ctor in (
            lambda: _make_stream_cmd("START"),
        ):
            cmd = cmd_ctor()
            if cmd is not None:
                try:
                    st.issue_stream_cmd(cmd)
                    print("   issue_stream_cmd(START) ok — re-testing recv:")
                    print("   ", _recv_test(st, "post-start"))
                    started = True
                    break
                except Exception as e:
                    print(f"   issue_stream_cmd failed: {e}")
        if not started:
            print("   (could not construct/issue a stream_cmd — see dump above)")
        # 2) max samples per recv?
        if hasattr(d, "get_max_num_samps"):
            print("  get_max_num_samps(0) =", d.get_max_num_samps(0))
        # 3) recv with an EXPLICIT num and long timeout (some bindings want n)
        try:
            meta = uhd.types.RXMetadata()
            buf = np.zeros(1024, dtype=np.complex64)
            n = st.recv(buf, meta, 1.0)   # long timeout
            print(f"  recv(buf, meta, 1.0s) -> {n} samples (absmax={float(np.abs(buf[:max(n,1)]).max()) if n else 0})")
        except Exception as e:
            print("  recv(buf,meta,1.0) failed:", e)
        # 4) Is the gain actually set / chain on? re-read
        try:
            print("  current gain:", d.get_rx_gain(0), " freq:", d.get_rx_freq(0), " rate:", d.get_rx_rate(0))
        except Exception as e:
            print("  could not re-read gain/freq/rate:", e)
        print("  INTERPRETATION: if gain/freq/rate read back correctly but recv is")
        print("  still 0 with a long timeout, the board is up but the antenna path")
        print("  is likely open-circuit (no antenna plugged in) OR a signal is")
        print("  required. A B205mini with NO antenna on the RF port can show 0.")
except Exception as e:
    print("  failed:", repr(e))

print("\nDONE")
