"""
elrs_sdr command-line interface.

Subcommands:
  info       — probe the attached UHD device (gains, antennas, sample rates)
  scan       — sweep the 2.4 GHz band, report where energy is (find ELRS hops)
  capture    — capture IQ to a .complex8 file for later decoding
  monitor    — live decode loop: capture -> LoRa demod -> CRC -> JSON lines
  decode     — decode a previously captured .complex8 file offline
  bind-capture — capture a TX in bind mode to recover the link UID (on-ramp)
  tx         — (FUTURE, gated) transmit a constructed ELRS frame

TX is behind an explicit --i-am-authorized flag because transmitting on drone
control bands is the legally/ethically sensitive half of this tool.
"""

from __future__ import annotations

import argparse
import json
import sys
import time

import numpy as np

from . import lora, ota, fhss, crc
from .radio import RadioDevice, UHDNotInstalled, read_complex8


# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------
_uhd = None


def _need_uhd():
    """Lazy-load UHD through the shared bootstrap (path scan + self-diagnosing
    error). Exits with code 2 and a useful message if UHD is genuinely absent."""
    global _uhd
    if _uhd is not None:
        return
    from .uhd_bootstrap import load_uhd, UHDNotInstalled
    try:
        _uhd = load_uhd()
    except UHDNotInstalled as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(2)


def _open_radio(args) -> RadioDevice:
    return RadioDevice(args.device, rx_channel=args.rx_chan, tx_channel=args.tx_chan)


def _describe_rx_rates(d, chan) -> str:
    """Describe the RX sample-rate range across bindings, without crashing.

    4.2+ returns a range object with get_min_rate()/get_max_rate();
    4.9/4.11 `get_rx_rates()` may return a list OR a meta_range_t (which has
    get_min_num()/get_max_num()/get_step_num() but no len()). Handle all of it.
    """
    # Preferred: get_rx_sample_rates() -> range object
    for m in ("get_rx_sample_rates",):
        if hasattr(d, m):
            try:
                sr = getattr(d, m)(chan)
                return (f"{sr.get_min_rate()/1e6:.3f} - {sr.get_max_rate()/1e6:.3f} "
                        f"Msps, step {sr.get_step_rate()/1e6:.4f} Msps")
            except Exception:
                pass
    # Fallback: get_rx_rates() -> list or meta_range_t
    if hasattr(d, "get_rx_rates"):
        try:
            r = d.get_rx_rates(chan)
            # meta_range_t: has get_min_num/get_max_num, no len()
            if hasattr(r, "get_min_num"):
                return (f"{r.get_min_num()/1e6:.3f} - {r.get_max_num()/1e6:.3f} "
                        f"Msps (continuous range)")
            # plain list of supported rates
            if isinstance(r, (list, tuple)) and r:
                return (f"{len(r)} supported; min {min(r)/1e6:.3f} - "
                        f"max {max(r)/1e6:.3f} Msps")
        except Exception as e:
            return f"(n/a: {e})"
    return "(n/a)"


def _print_json(obj):
    print(json.dumps(obj, separators=(",", ":")), flush=True)


# ----------------------------------------------------------------------------
# info
# ----------------------------------------------------------------------------
def cmd_info(args):
    _need_uhd()
    r = _open_radio(args)
    d = r.device
    print(f"device args : {args.device}")
    # firmware version: 4.2+ get_firmware_version(); 4.9/4.11 get_firmware_revision()
    for m in ("get_firmware_version", "get_firmware_revision"):
        if hasattr(d, m):
            try:
                print(f"firmware    : {getattr(d, m)()}")
                break
            except Exception as e:
                print(f"firmware    : (n/a: {e})")
    try:
        print(f"hw revision : {d.get_mboard_firmware_versions()}")
    except Exception:
        pass
    print(f"RX gain range : {r.get_gain_range()}")
    print(f"RX antennas   : {r.get_antennas('rx')}")
    try:
        print(f"TX antennas   : {r.get_antennas('tx')}")
    except Exception as e:
        print(f"TX antennas   : (n/a: {e})")
    # sample-rate range: 4.2+ get_rx_sample_rates(); 4.9/4.11 may return a
    # meta_range_t (use its own min/max methods) or a list — handle both.
    print("RX sample rate:", _describe_rx_rates(d, args.rx_chan))


# ----------------------------------------------------------------------------
# scan
# ----------------------------------------------------------------------------
def cmd_scan(args):
    _need_uhd()
    r = _open_radio(args)
    # coarse sweep across the 2.4 GHz ELRS band
    n = args.sweep
    f0 = 2.400e9
    f1 = 2.480e9
    step = (f1 - f0) / n
    r.tune(f0, args.srate, args.gain, args.antenna)
    print(f"sweeping {f0/1e9:.3f}-{f1/1e9:.3f} GHz in {n} steps "
          f"@ {args.srate/1e3:.0f} ksps, {args.dwell_ms} ms dwell", flush=True)
    results = []
    stream = r._open_rx_stream()
    buf = np.zeros(8192, dtype=np.complex64)
    for i in range(n):
        f = f0 + step * i
        r.set_freq(f)
        time.sleep(args.dwell_ms / 1000.0)
        # grab a burst and measure power
        cnt = r._recv(stream, buf, 0.2)
        if cnt:
            pwr = float(np.mean(np.abs(buf[:cnt]) ** 2))
            dbmish = 10 * np.log10(pwr + 1e-12)
        else:
            dbmish = -999.0
        results.append((f, dbmish))
        print(f"  {f/1e9:.4f} GHz  {dbmish:7.1f} dBref", flush=True)
    results.sort(key=lambda x: -x[1])
    print("\ntop 5 peaks:")
    for f, p in results[:5]:
        print(f"  {f/1e9:.4f} GHz  {p:7.1f} dBref")


# ----------------------------------------------------------------------------
# capture
# ----------------------------------------------------------------------------
def cmd_capture(args):
    _need_uhd()
    r = _open_radio(args)
    r.tune(args.freq, args.srate, args.gain, args.antenna)
    print(f"capturing {args.samples:,} IQ samples @ {args.freq/1e6:.1f} MHz, "
          f"{args.srate/1e3:.0f} ksps -> {args.out}", flush=True)
    t0 = time.time()
    r.capture(args.samples, args.out)
    print(f"done in {time.time()-t0:.1f}s", flush=True)


# ----------------------------------------------------------------------------
# decode (offline, from a .complex8 file)
# ----------------------------------------------------------------------------
def cmd_decode(args):
    samples = read_complex8(args.file)
    print(f"loaded {len(samples):,} samples from {args.file}", flush=True)
    _decode_samples(samples, args)


def _decode_samples(samples, args, label=""):
    """Run the RX pipeline over an IQ array and emit JSON lines."""
    rate = lora.ELRS_2G4_RATES[args.rate]
    params = lora.LoRaParams(sf=rate.sf, bw_hz=rate.bw_hz,
                             sample_rate=args.srate)
    # detect candidate frame starts (both IQ polarities)
    starts = []
    for inv in (False, True):
        p = lora.LoRaParams(sf=rate.sf, bw_hz=rate.bw_hz,
                            sample_rate=args.srate, invert_iq=inv)
        starts += [(s, inv) for s in lora.detect_sync_word(samples, p)]
    # dedupe close starts
    starts.sort()
    deduped = []
    for s, inv in starts:
        if not deduped or s - deduped[-1][0] > params.samples_per_symbol:
            deduped.append((s, inv))
    print(f"{label}{len(deduped)} candidate frame starts "
          f"(rate={args.rate}, SF{rate.sf})", flush=True)

    decoded = 0
    for s, inv in deduped:
        p = lora.LoRaParams(sf=rate.sf, bw_hz=rate.bw_hz,
                            sample_rate=args.srate, invert_iq=inv)
        raw = lora.demodulate_frame(samples, p, s, rate)
        if raw is None:
            continue
        pkt = _try_crc(raw, args)
        if pkt is not None:
            decoded += 1
            rec = pkt.to_dict()
            rec["sample"] = s
            rec["invert_iq"] = inv
            _print_json(rec)
    print(f"{label}decoded {decoded} CRC-valid packets", flush=True)


def _try_crc(raw: bytes, args) -> "ota.ElrsPacket | None":
    """
    Validate a raw frame against the link. Without a known UID we try:
      1. the UID supplied on the CLI (--uid), if given
      2. binding-mode init (OTA_VERSION_ID) — works for bind-capture files
    The nonce is scanned over 0..255 for non-sync packets since an offline
    decoder doesn't track the live nonce counter.
    """
    if args.uid:
        uid = bytes.fromhex(args.uid)
        init = ota.ota_uid_crc_init(uid)
    else:
        uid = None
        init = ota.bind_crc_init()

    is_full = len(raw) == ota.OTA8_PACKET_SIZE
    ptype = raw[0] & 0x3
    # scan nonce space; sync packets use nonce 0
    for nonce in ([0] if ptype == ota.PACKET_TYPE_SYNC else range(256)):
        pkt = ota.decode(raw, uid, init, nonce)
        if pkt is not None:
            return pkt
    return None


# ----------------------------------------------------------------------------
# monitor (live)
# ----------------------------------------------------------------------------
def cmd_monitor(args):
    _need_uhd()
    r = _open_radio(args)
    r.tune(args.freq, args.srate, args.gain, args.antenna)
    print(f"monitoring {args.freq/1e6:.1f} MHz @ {args.srate/1e3:.0f} ksps "
          f"(rate={args.rate}); Ctrl-C to stop", flush=True)
    rate = lora.ELRS_2G4_RATES[args.rate]
    chunk = 65536
    ring = bytearray()
    RING = 1 << 18
    try:
        for buf in r.rx_stream(chunk):
            ring.extend(buf.tobytes())
            if len(ring) > RING:
                del ring[:len(ring) - RING]
            arr = np.frombuffer(bytes(ring), dtype=np.complex64)
            # reuse the offline decoder over the rolling window
            _decode_samples(arr, args, label="[live] ")
    except KeyboardInterrupt:
        print("\nstopped", flush=True)


# ----------------------------------------------------------------------------
# bind-capture
# ----------------------------------------------------------------------------
def cmd_bind_capture(args):
    _need_uhd()
    r = _open_radio(args)
    # bind mode: 50 Hz rate, sync channel (ISM2G4 chan 40 = 2440 MHz),
    # InvertIQ. Tune to the sync channel and capture.
    dom = fhss.DOMAINS[fhss.DEFAULT_2G4_DOMAIN]
    f = dom.channel_freq(dom.sync_channel)
    r.tune(f, args.srate, args.gain, args.antenna)
    print(f"bind-capture @ {f/1e6:.1f} MHz (sync ch {dom.sync_channel}), "
          f"{args.samples:,} samples -> {args.out}", flush=True)
    r.capture(args.samples, args.out)
    print("\nNow decode with binding-mode init (default) to extract the UID:",
          flush=True)
    print(f"  elrs-sdr decode {args.out} --rate 50Hz", flush=True)


# ----------------------------------------------------------------------------
# tx (future, gated)
# ----------------------------------------------------------------------------
def cmd_tx(args):
    if not getattr(args, "i_am_authorized_to_transmit", False):
        print("refusing: TX is disabled by default. Re-run with "
              "--i-am-authorized-to-transmit only if you own the target link "
              "and are in a regulated/authorized context.", file=sys.stderr)
        sys.exit(3)
    _need_uhd()
    r = _open_radio(args)
    rate = lora.ELRS_2G4_RATES[args.rate]
    # build a frame (placeholder: sync packet)
    raw = ota.build_sync(is_full=rate.is_full, fhss_index=0, nonce=0,
                         rf_rate_enum=rate.sf, uid4=0, uid5=0)
    dom = fhss.DOMAINS[fhss.DEFAULT_2G4_DOMAIN]
    f = args.freq or dom.channel_freq(0)
    r.tx_tune(f, args.srate, args.gain, args.antenna)
    wf = lora.modulate_frame(rate, raw, args.srate)
    print(f"TX {len(wf)} samples @ {f/1e6:.1f} MHz (rate={args.rate})", flush=True)
    r.tx_stream(wf)
    print("transmit complete", flush=True)


# ----------------------------------------------------------------------------
# parser
# ----------------------------------------------------------------------------
def build_parser():
    p = argparse.ArgumentParser(prog="elrs-sdr",
                                description="Capture/decode (and later TX) "
                                            "ExpressLRS drone signals.")
    p.add_argument("--device", default="type=b200",
                   help="UHD device args (default type=b200 = auto B205/B210)")
    p.add_argument("--rx-chan", type=int, default=0)
    p.add_argument("--tx-chan", type=int, default=0)
    p.add_argument("--antenna", default=None, help="antenna name")

    sub = p.add_subparsers(dest="cmd", required=True)

    def add_common(sp, need_freq=True):
        if need_freq:
            sp.add_argument("--freq", type=float, default=2.44e9,
                            help="center frequency Hz (default 2.44 GHz)")
        sp.add_argument("--srate", type=float, default=4e6,
                        help="IQ sample rate (default 4 Msps; >=4x LoRa BW)")
        sp.add_argument("--gain", type=float, default=40, help="RF gain dB")
        sp.add_argument("--rate", default="250Hz",
                        choices=sorted(lora.ELRS_2G4_RATES),
                        help="ELRS air rate (default 250Hz)")

    sp = sub.add_parser("info", help="probe the device"); sp.set_defaults(fn=cmd_info)

    sp = sub.add_parser("scan", help="sweep the 2.4 GHz band")
    sp.add_argument("--sweep", type=int, default=80, help="number of sweep steps")
    sp.add_argument("--dwell-ms", type=int, default=25, help="ms per step")
    sp.add_argument("--srate", type=float, default=2e6)
    sp.add_argument("--gain", type=float, default=30)
    sp.add_argument("--antenna", default=None)
    sp.set_defaults(fn=cmd_scan)

    sp = sub.add_parser("capture", help="capture IQ to a .complex8 file")
    add_common(sp)
    sp.add_argument("--samples", type=int, default=1 << 20,
                    help="number of IQ samples (default 1M)")
    sp.add_argument("--out", default="capture.complex8")
    sp.set_defaults(fn=cmd_capture)

    sp = sub.add_parser("decode", help="decode a .complex8 file offline")
    sp.add_argument("file")
    add_common(sp, need_freq=False)
    sp.add_argument("--uid", default=None,
                    help="link UID hex (12 chars) for CRC init; omit for "
                         "binding-mode init")
    sp.set_defaults(fn=cmd_decode)

    sp = sub.add_parser("monitor", help="live decode loop")
    add_common(sp)
    sp.set_defaults(fn=cmd_monitor)

    sp = sub.add_parser("bind-capture", help="capture a TX in bind mode")
    add_common(sp, need_freq=False)
    sp.add_argument("--samples", type=int, default=1 << 20)
    sp.add_argument("--out", default="bind.complex8")
    sp.set_defaults(fn=cmd_bind_capture)

    sp = sub.add_parser("tx", help="(future) transmit an ELRS frame [gated]")
    add_common(sp)
    sp.add_argument("--i-am-authorized-to-transmit",
                    action="store_true",
                    help="required to enable TX; confirm authorization")
    sp.set_defaults(fn=cmd_tx)

    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    args.fn(args)


if __name__ == "__main__":
    main()
